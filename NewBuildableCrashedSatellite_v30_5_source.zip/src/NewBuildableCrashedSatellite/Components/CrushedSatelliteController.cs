using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    internal sealed class CrushedSatelliteController : SatelliteControllerBase
    {
        private const int X_MIN = -SatelliteTuning.CRUSHED_MAX_EXTEND; // -6
        private const int X_MAX = (SatelliteTuning.CRUSHED_BASE_WIDTH - 1) + SatelliteTuning.CRUSHED_MAX_EXTEND; // 11
        private const int Y_MIN = 0;
        private const int Y_MAX = (SatelliteTuning.CRUSHED_BASE_HEIGHT - 1) + SatelliteTuning.CRUSHED_MAX_EXTEND; // 11

        private readonly List<TileEmitter> tileEmitters = new List<TileEmitter>(256);

        private RadiationEmitter vanillaEmitter;
        private Light2D light;
        private CrushedSatelliteRangeSettings rangeSettings;
        private Building building;

        private bool lastEnabled = true;
        private bool lastPoweredMode = false;

        private struct TileEmitter
        {
            public int x;
            public int y;
            public RadiationEmitter emitter;
            public GameObject go;
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();

            // Keep the UI overheat value stable and match the requested stop temperature logic.
            TryOverrideOverheatTemperature(SatelliteTuning.CRUSHED_OVERHEAT_TEMP_K);
            TryForceUnobtaniumForBuildable();
            EnsureEnergyConsumerWatts(SatelliteTuning.CRUSHED_POWER_WATTS);

            building = GetComponent<Building>();
            rangeSettings = GetComponent<CrushedSatelliteRangeSettings>();
            if (rangeSettings == null)
                rangeSettings = gameObject.AddOrGet<CrushedSatelliteRangeSettings>();

            vanillaEmitter = GetComponent<RadiationEmitter>();
            if (vanillaEmitter != null)
            {
                vanillaEmitter.emitRads = 0f;
                vanillaEmitter.enabled = false;
            }

            light = GetComponent<Light2D>();

            EnsureTileEmitters();

            lastEnabled = true;
            lastPoweredMode = false;
            UpdateTileEmitters(forceAll: true, enabledOverride: lastEnabled, poweredOverride: lastPoweredMode);
        }

        public void OnRangeSettingsApplied()
        {
            // Re-apply using the last known state (do not force-enable radiation while disabled/too hot).
            UpdateTileEmitters(forceAll: true, enabledOverride: lastEnabled, poweredOverride: lastPoweredMode);
        }

        protected override void Sim1000msImpl(float dt)
        {
            bool tempOk = TemperatureGate(SatelliteTuning.CRUSHED_STOP_C);
            bool powerSatisfied = IsPoweredSatisfied();
            bool fullyOperational = IsFullyOperational();
            bool logicOn = IsAutomationSignalOn();

            bool enabled;
            if (!tempOk)
                enabled = false;
            else if (powerSatisfied)
                enabled = fullyOperational && logicOn;
            else
                enabled = true; // ignore automation when not powered

            bool poweredMode = enabled && powerSatisfied;

            lastEnabled = enabled;
            lastPoweredMode = poweredMode;

            UpdateTileEmitters(forceAll: false, enabledOverride: enabled, poweredOverride: poweredMode);

            // Keep Operational active state aligned with our effect enablement.
            // Only mark the building “active” when it is actually in powered mode.
            TrySetOperationalActive(tempOk);

            if (enabled)
            {
                float heat = poweredMode
                    ? SatelliteTuning.CRUSHED_HEAT_POWERED_KDTU_PER_S
                    : SatelliteTuning.CRUSHED_HEAT_BASE_KDTU_PER_S;
                AddHeatToSelf(heat, dt);
            }

            if (light != null)
                SetLight(light, poweredMode, SatelliteTuning.CRUSHED_POWERED_LUX);

            if (poweredMode)
                EmitOutputs(dt);
        }

        private void EnsureTileEmitters()
        {
            if (tileEmitters.Count > 0) return;

            // NOTE: RadiationEmitter does not reliably support multiple instances on the same GameObject
            // across all ONI builds. Use child GameObjects per-tile instead.
            for (int y = Y_MIN; y <= Y_MAX; y++)
            {
                for (int x = X_MIN; x <= X_MAX; x++)
                {
                    var child = new GameObject($"NBCS_CrushedRad_{x}_{y}");
                    child.transform.SetParent(transform);
                    child.transform.localPosition = Vector3.zero;

                    var e = child.AddComponent<RadiationEmitter>();
                    e.emitRads = 0f;
                    e.emitRadiusX = 0;
                    e.emitRadiusY = 0;
                    e.emitAngle = 360f;

                    // Best-effort to enforce constant emission (field names differ between ONI builds).
                    try
                    {
                        var t = e.GetType();

                        var f = t.GetField("emitType", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                        if (f != null && f.FieldType.IsEnum)
                        {
                            foreach (var v in Enum.GetValues(f.FieldType))
                            {
                                if (string.Equals(v.ToString(), "Constant", StringComparison.OrdinalIgnoreCase))
                                {
                                    f.SetValue(e, v);
                                    break;
                                }
                            }
                        }

                        foreach (var field in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                        {
                            var name = (field.Name ?? string.Empty).ToLowerInvariant();
                            if (field.FieldType == typeof(bool) && name.Contains("pulse"))
                            {
                                field.SetValue(e, false);
                                continue;
                            }

                            if ((field.FieldType == typeof(float) || field.FieldType == typeof(int)) &&
                                (name.Contains("pulse") || name.Contains("interval") || name.Contains("period") || name.Contains("random")))
                            {
                                if (field.FieldType == typeof(float))
                                    field.SetValue(e, 0f);
                                else
                                    field.SetValue(e, 0);
                            }
                        }
                    }
                    catch
                    {
                    }

                    // Child RadiationEmitters are created after the parent has spawned.
                    // Explicitly spawn them so they register with the simulation.
                    try { e.Spawn(); } catch { }

                    tileEmitters.Add(new TileEmitter { x = x, y = y, emitter = e, go = child });
                }
            }
        }

        private void UpdateTileEmitterTransforms(int originCell)
        {
            int originX = Grid.CellToXY(originCell).x;
            int originY = Grid.CellToXY(originCell).y;

            for (int i = 0; i < tileEmitters.Count; i++)
            {
                var te = tileEmitters[i];
                if (te.go == null)
                    continue;

                int cell = Grid.XYToCell(originX + te.x, originY + te.y);
                te.go.transform.position = Grid.CellToPosCCC(cell, Grid.SceneLayer.Building);
            }
        }

        private void UpdateTileEmitters(bool forceAll, bool enabledOverride, bool poweredOverride)
        {
            int originCell = Grid.PosToCell(gameObject);
            UpdateTileEmitterTransforms(originCell);

            int extendLeft = Mathf.Clamp(rangeSettings.extendLeft, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);
            int extendRight = Mathf.Clamp(rangeSettings.extendRight, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);
            int extendUp = Mathf.Clamp(rangeSettings.extendUp, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);

            int xMin = -extendLeft;
            int xMax = (SatelliteTuning.CRUSHED_BASE_WIDTH - 1) + extendRight;
            int yMin = 0;
            int yMax = (SatelliteTuning.CRUSHED_BASE_HEIGHT - 1) + extendUp;

            int width = SatelliteTuning.CRUSHED_BASE_WIDTH + extendLeft + extendRight;
            int height = SatelliteTuning.CRUSHED_BASE_HEIGHT + extendUp;
            int area = Mathf.Max(1, width * height);

            if (light != null)
            {
                float diag = Mathf.Sqrt(width * width + height * height);
                light.Range = diag;
            }

            float total = poweredOverride
                ? SatelliteTuning.CrushedTotalRadsPerCyclePowered()
                : SatelliteTuning.CrushedTotalRadsPerCycleBase();

            float perTile = enabledOverride ? (total / area) : 0f;

            for (int i = 0; i < tileEmitters.Count; i++)
            {
                var te = tileEmitters[i];
                bool inside = (te.x >= xMin && te.x <= xMax && te.y >= yMin && te.y <= yMax);
                float target = inside ? perTile : 0f;

                if (forceAll || te.emitter.emitRads != target)
                {
                    te.emitter.emitRads = target;

                    if (target > 0f)
                    {
                        // We want a strict "cell-only" ambient source for the Crushed Satellite
                        // rectangle (no radial spread, no falloff). For Constant emitters the
                        // effective range is determined by emitRadiusX/Y.
                        // Setting both radii to 0 confines emission to the emitter cell.
                        te.emitter.emitRadiusX = 0;
                        te.emitter.emitRadiusY = 0;
                        te.emitter.emitAngle = 360f;
                    }
                    else
                    {
                        te.emitter.emitRads = 0f;
                    }
                }
            }
        }

        private void EmitOutputs(float dt)
        {
            try
            {
                // Use the exact same offsets configured on the BuildingDef.
                int originCell = Grid.PosToCell(gameObject);
                int liquidCell = Grid.OffsetCell(originCell, SatelliteTuning.CRUSHED_LIQUID_OUTPUT_OFFSET);
                int gasCell = Grid.OffsetCell(originCell, SatelliteTuning.CRUSHED_GAS_OUTPUT_OFFSET);

                float liquidMass = SatelliteTuning.CRUSHED_LIQUID_KG_PER_S * dt;
                float gasMass = SatelliteTuning.CRUSHED_GAS_KG_PER_S * dt;

                float liquidTempK = SatelliteTuning.CToK(SatelliteTuning.CRUSHED_LIQUID_TEMP_C);
                float gasTempK = SatelliteTuning.CToK(SatelliteTuning.CRUSHED_GAS_TEMP_C);

                if (Game.Instance != null)
                {
                    if (Game.Instance.liquidConduitFlow != null)
                        Game.Instance.liquidConduitFlow.AddElement(liquidCell, SimHashes.DirtyWater, liquidMass, liquidTempK, 0, 0);

                    if (Game.Instance.gasConduitFlow != null)
                        Game.Instance.gasConduitFlow.AddElement(gasCell, SimHashes.Methane, gasMass, gasTempK, 0, 0);
                }
            }
            catch (Exception e)
            {
                Debug.LogError("[NewBuildableCrashedSatellite] CrushedSatellite outputs error: " + e);
            }
        }
    }
}
