using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    internal sealed class CrashedSatelliteController : SatelliteControllerBase
    {
        private RadiationEmitter emitter;

        protected override void OnSpawn()
        {
            base.OnSpawn();

            // Force Neutronium (prevents melting / material-based radiation side effects).
            TryForceUnobtaniumForBuildable();

            // Force the requested overheat temperature (some ONI versions can ignore BuildingDef changes).
            TryOverrideOverheatTemperature(SatelliteTuning.CRASHED_OVERHEAT_TEMP_K);

            emitter = GetComponent<RadiationEmitter>();
            NormalizeEmitterForBuildable(emitter);

            if (emitter != null)
            {
                // Ensure a sane initial state (base mode always emits, automation/power not used).
                emitter.enabled = true;
                emitter.emitRads = SatelliteTuning.CRASHED_RADS_PER_CYCLE;
            }
        }

        protected override void Sim1000msImpl(float dt)
        {
            bool enabled = TemperatureGate(SatelliteTuning.CRASHED_STOP_C);
            ApplyEmitter(enabled);
            if (enabled)
                AddHeatToSelf(SatelliteTuning.CRASHED_HEAT_KDTU_PER_S, dt);

            // Keep Operational active state aligned with our effect enablement.
            TrySetOperationalActive(enabled);
        }

        private void ApplyEmitter(bool enabled)
        {
            if (emitter == null) return;
            emitter.enabled = enabled;
            emitter.emitRads = enabled ? SatelliteTuning.CRASHED_RADS_PER_CYCLE : 0f;
        }
    }
}
