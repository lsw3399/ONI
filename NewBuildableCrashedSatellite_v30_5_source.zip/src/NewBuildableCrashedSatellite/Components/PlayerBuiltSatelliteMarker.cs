using KSerialization;

namespace NewBuildableCrashedSatellite.Components
{
    [SerializationConfig(MemberSerialization.OptIn)]
    internal sealed class PlayerBuiltSatelliteMarker : KMonoBehaviour
    {
        // Marker component: existence of this component is the marker.
    }
}
