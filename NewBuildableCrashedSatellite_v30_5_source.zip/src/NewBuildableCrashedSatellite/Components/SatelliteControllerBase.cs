using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using NewBuildableCrashedSatellite.Utils;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    internal abstract class SatelliteControllerBase : KMonoBehaviour, ISim1000ms
    {
        protected PrimaryElement primaryElement;
        protected Operational operational;
        protected EnergyConsumer _energyConsumer;

        // Prevent rapid on/off oscillation around the stop temperature.
        // Without this, self-heating sources can hover around the threshold and appear to “pulse”.
        protected const float TEMP_HYSTERESIS_C = 10f;
        private bool pausedByTemp;

        private bool isBuildableCached;
        private bool isBuildable;

        protected bool IsBuildableSatellite()
        {
            if (isBuildableCached)
                return isBuildable;

            try
            {
                var kpid = GetComponent<KPrefabID>();
                if (kpid == null)
                {
                    isBuildable = false;
                }
                else
                {
                    string id = kpid.PrefabTag.ToString();
                    isBuildable =
                        id == SatelliteIds.BUILDABLE_CRASHED ||
                        id == SatelliteIds.BUILDABLE_WRECKED ||
                        id == SatelliteIds.BUILDABLE_CRUSHED;
                }
            }
            catch
            {
                isBuildable = false;
            }

            isBuildableCached = true;
            return isBuildable;
        }

        protected override void OnSpawn()
        {
            base.OnSpawn();
            primaryElement = GetComponent<PrimaryElement>() ?? GetComponentInChildren<PrimaryElement>();
            operational = GetComponent<Operational>() ?? GetComponentInChildren<Operational>();
            _energyConsumer = GetComponent<EnergyConsumer>() ?? GetComponentInChildren<EnergyConsumer>();

            // Cache buildable state early.
            IsBuildableSatellite();

            // Player-built satellites can inherit a low melting point from the chosen construction
            // ingredient (e.g. Uranium Ore). Force the base element to Unobtanium so the building
            // itself does not melt.
            TryForceUnobtaniumForBuildable();

            // Construction can re-apply a construction material element late in the spawn sequence.
            // Re-apply on the next frame to ensure the final PrimaryElement is Unobtanium.
            try
            {
                StartCoroutine(ForceUnobtaniumNextFrame());
            }
            catch
            {
                // ignore; we already applied once
            }
        }

        private IEnumerator ForceUnobtaniumNextFrame()
        {
            yield return null;
            TryForceUnobtaniumForBuildable();
        }

        /// <summary>
        /// Stop the building when it exceeds the given temperature (in °C), with a small hysteresis
        /// before resuming to avoid visible pulsing.
        /// </summary>
        protected bool TemperatureGate(float stopTempC)
        {
            if (primaryElement == null)
                return true;

            float t = TemperatureC;
            if (!pausedByTemp)
            {
                if (t > stopTempC)
                    pausedByTemp = true;
            }
            else
            {
                if (t < stopTempC - TEMP_HYSTERESIS_C)
                    pausedByTemp = false;
            }

            return !pausedByTemp;
        }

        public void Sim1000ms(float dt)
        {
            try
            {
                Sim1000msImpl(dt);
            }
            catch (Exception e)
            {
                Debug.LogError("[NewBuildableCrashedSatellite] Exception in Sim1000ms for " + gameObject.name + ": " + e);
            }
        }

        protected abstract void Sim1000msImpl(float dt);

        protected float TemperatureC
        {
            get
            {
                if (primaryElement == null) return 0f;
                return primaryElement.Temperature - 273.15f;
            }
        }

        /// <summary>
        /// Returns true if this building currently has enough power.
        /// </summary>
        protected bool IsPoweredSatisfied()
        {
            if (_energyConsumer == null)
                return false;

            // 1) Try the obvious / common names first (property, field, or method).
            string[] names = new[]
            {
                "IsPowered",
                "HasPower",
                "IsWattageSatisfied",
                "WattageSatisfied",
                "IsPowerAvailable",
                "PowerAvailable",
                "IsConnected",
                "IsConnectedToCircuit",
                "IsConnectedToGrid",
                "IsCircuitConnected",
                "GetIsPowered"
            };

            foreach (string name in names)
            {
                // Signature: TryGetBool(object target, out bool value, params string[] memberNames)
                // so the out parameter must be the 2nd argument.
                if (ReflectionUtil.TryGetBool(_energyConsumer, out bool b, name))
                    return b;

                object o = ReflectionUtil.TryCall(_energyConsumer, name);
                if (o is bool bb)
                    return bb;
            }

            // 2) Fallback: scan boolean members and pick the best candidate by name scoring.
            //    This avoids compile-time dependency on unstable API names across ONI versions.
            try
            {
                Type t = _energyConsumer.GetType();
                bool found = false;
                bool bestValue = false;
                int bestScore = int.MinValue;

                foreach (PropertyInfo p in t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (p == null || p.PropertyType != typeof(bool) || !p.CanRead)
                        continue;

                    int score = ScorePowerMemberName(p.Name);
                    if (score <= bestScore)
                        continue;

                    try
                    {
                        object v = p.GetValue(_energyConsumer, null);
                        if (v is bool bv)
                        {
                            bestScore = score;
                            bestValue = bv;
                            found = true;
                        }
                    }
                    catch { }
                }

                foreach (FieldInfo f in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    if (f == null || f.FieldType != typeof(bool))
                        continue;

                    int score = ScorePowerMemberName(f.Name);
                    if (score <= bestScore)
                        continue;

                    try
                    {
                        object v = f.GetValue(_energyConsumer);
                        if (v is bool bv)
                        {
                            bestScore = score;
                            bestValue = bv;
                            found = true;
                        }
                    }
                    catch { }
                }

                if (found && bestScore > 0)
                    return bestValue;
            }
            catch { }

            return false;
        }

        private static int ScorePowerMemberName(string name)
        {
            if (string.IsNullOrEmpty(name))
                return 0;

            string n = name.ToLowerInvariant();
            int score = 0;

            if (n.Contains("watt") && (n.Contains("satisfied") || n.Contains("available") || n.Contains("ok")))
                score += 8;

            if (n == "ispowered" || n == "powered" || n.Contains("ispowered") || n.Contains("powered"))
                score += 6;

            if (n.Contains("haspower") || n.Contains("poweravailable") || n.Contains("power_available"))
                score += 6;

            if (n.Contains("satisfied") || n.Contains("available"))
                score += 2;

            if (n.Contains("connected") || n.Contains("connection") || n.Contains("circuit") || n.Contains("grid"))
                score += 1;

            if (n.Contains("disconnected") || n.Contains("unpowered") || n.Contains("nopower") || n.Contains("no_power"))
                score -= 10;

            // Avoid selecting unrelated state booleans if a better match exists.
            if (n.Contains("initialized") || n.Contains("spawn") || n.Contains("loaded"))
                score -= 2;

            return score;
        }


        /// <summary>
        /// Ensure the EnergyConsumer on this building is configured to draw the requested wattage.
        ///
        /// This is intentionally reflection-driven because ONI has changed EnergyConsumer field/
        /// property names across versions.
        /// </summary>
        protected void EnsureEnergyConsumerWatts(float watts)
        {
            if (_energyConsumer == null)
                return;

            try
            {
                // Common field/property names used across builds.
                TrySetNumericMemberByAnyName(
                    _energyConsumer,
                    watts,
                    "WattsNeededWhenActive",
                    "wattsNeededWhenActive",
                    "WattsNeeded",
                    "wattsNeeded",
                    "EnergyConsumptionWhenActive",
                    "energyConsumptionWhenActive",
                    "Wattage",
                    "wattage");

                // Common setter method names.
                TryCallNumericSetterByAnyName(
                    _energyConsumer,
                    watts,
                    "SetWattsNeededWhenActive",
                    "SetWattsNeeded",
                    "SetWattage",
                    "SetPowerConsumption",
                    "SetEnergyConsumptionWhenActive");
            }
            catch
            {
            }
        }

        private static bool TrySetNumericMemberByAnyName(object target, float value, params string[] names)
        {
            if (target == null || names == null || names.Length == 0)
                return false;

            var t = target.GetType();
            const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

            for (int i = 0; i < names.Length; i++)
            {
                var name = names[i];
                if (string.IsNullOrEmpty(name))
                    continue;

                try
                {
                    var f = t.GetField(name, Flags);
                    if (f != null)
                    {
                        if (f.FieldType == typeof(float))
                        {
                            f.SetValue(target, value);
                            return true;
                        }
                        if (f.FieldType == typeof(int))
                        {
                            f.SetValue(target, Mathf.RoundToInt(value));
                            return true;
                        }
                        if (f.FieldType == typeof(double))
                        {
                            f.SetValue(target, (double)value);
                            return true;
                        }
                    }

                    var p = t.GetProperty(name, Flags);
                    if (p != null && p.CanWrite)
                    {
                        if (p.PropertyType == typeof(float))
                        {
                            p.SetValue(target, value, null);
                            return true;
                        }
                        if (p.PropertyType == typeof(int))
                        {
                            p.SetValue(target, Mathf.RoundToInt(value), null);
                            return true;
                        }
                        if (p.PropertyType == typeof(double))
                        {
                            p.SetValue(target, (double)value, null);
                            return true;
                        }
                    }
                }
                catch
                {
                }
            }

            return false;
        }

        private static bool TryCallNumericSetterByAnyName(object target, float value, params string[] methodNames)
        {
            if (target == null || methodNames == null || methodNames.Length == 0)
                return false;

            var t = target.GetType();
            const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

            try
            {
                var methods = t.GetMethods(Flags);
                for (int i = 0; i < methodNames.Length; i++)
                {
                    var name = methodNames[i];
                    if (string.IsNullOrEmpty(name))
                        continue;

                    foreach (var m in methods)
                    {
                        if (m == null || m.Name != name)
                            continue;

                        var ps = m.GetParameters();
                        if (ps == null || ps.Length != 1)
                            continue;

                        var pt = ps[0].ParameterType;
                        object arg = null;

                        if (pt == typeof(float))
                            arg = value;
                        else if (pt == typeof(int))
                            arg = Mathf.RoundToInt(value);
                        else if (pt == typeof(double))
                            arg = (double)value;
                        else
                            continue;

                        m.Invoke(target, new[] { arg });
                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }
        /// <summary>
        /// Returns true if automation/logic allows operation.
        ///
        /// If the logic flag cannot be determined, returns true (fail-open) so the building doesn't
        /// unexpectedly disable on unknown ONI versions.
        /// </summary>
        protected bool IsAutomationSignalOn()
        {
            if (operational != null)
            {
                try
                {
                    if (TryGetOperationalLogicFlag(out var logicFlag))
                        return operational.GetFlag(logicFlag);
                }
                catch
                {
                }
            }

            return true;
        }

        protected void TrySetOperationalActive(bool active)
        {
            if (operational == null)
                return;

            try
            {
                // Operational.SetActive(bool) exists in many ONI versions, but we call via reflection
                // so we don't depend on a specific signature.
                var m = operational.GetType().GetMethod(
                    "SetActive",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                    null,
                    new[] { typeof(bool) },
                    null);
                if (m != null)
                {
                    m.Invoke(operational, new object[] { active });
                    return;
                }

                // Fallback: some builds expose "SetActiveState".
                m = operational.GetType().GetMethod(
                    "SetActiveState",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
                    null,
                    new[] { typeof(bool) },
                    null);
                if (m != null)
                    m.Invoke(operational, new object[] { active });
            }
            catch
            {
            }
        }

        protected void NormalizeEmitterForBuildable(RadiationEmitter emitter)
        {
            if (emitter == null)
                return;
            if (!IsBuildableSatellite())
                return;

            try
            {
                var t = emitter.GetType();

                // Attempt to force a constant emit type if available.
                try
                {
                    var fEmitType = t.GetField("emitType", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (fEmitType != null && fEmitType.FieldType.IsEnum)
                    {
                        object constantVal = Enum.GetValues(fEmitType.FieldType).Cast<object>()
                            .FirstOrDefault(v => string.Equals(v.ToString(), "Constant", StringComparison.OrdinalIgnoreCase));
                        if (constantVal != null)
                            fEmitType.SetValue(emitter, constantVal);
                    }

                    var pEmitType = t.GetProperty("emitType", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (pEmitType != null && pEmitType.CanWrite && pEmitType.PropertyType.IsEnum)
                    {
                        object constantVal = Enum.GetValues(pEmitType.PropertyType).Cast<object>()
                            .FirstOrDefault(v => string.Equals(v.ToString(), "Constant", StringComparison.OrdinalIgnoreCase));
                        if (constantVal != null)
                            pEmitType.SetValue(emitter, constantVal, null);
                    }
                }
                catch
                {
                    // ignored
                }

                // Clear pulse/random behaviour if present.
                foreach (var f in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
                {
                    var name = (f.Name ?? string.Empty).ToLowerInvariant();
                    if (f.FieldType == typeof(bool) && name.Contains("pulse"))
                    {
                        f.SetValue(emitter, false);
                        continue;
                    }

                    if ((f.FieldType == typeof(float) || f.FieldType == typeof(int)) &&
                        (name.Contains("pulse") || name.Contains("interval") || name.Contains("period") || name.Contains("random")))
                    {
                        if (f.FieldType == typeof(float))
                            f.SetValue(emitter, 0f);
                        else
                            f.SetValue(emitter, 0);
                    }
                }
            }
            catch
            {
            }
        }

        private static bool TryGetOperationalPowerFlag(out Operational.Flag flag)
        {
            // The enum member name has differed between ONI versions.
            // We avoid hard-coding a specific member like Operational.Flag.Powered.

            var flagType = typeof(Operational.Flag);

            string[] preferredNames = new[]
            {
                "Powered",
                "HasPower",
                "Power",
                "RequirePower",
                "PowerCircuit",
                "PowerInput",
            };

            foreach (var name in preferredNames)
            {
                try
                {
                    if (Enum.IsDefined(flagType, name))
                    {
                        flag = (Operational.Flag)Enum.Parse(flagType, name, ignoreCase: false);
                        return true;
                    }
                }
                catch
                {
                }
            }

            try
            {
                foreach (var name in Enum.GetNames(flagType))
                {
                    if (!string.IsNullOrEmpty(name) && name.IndexOf("Power", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        flag = (Operational.Flag)Enum.Parse(flagType, name, ignoreCase: true);
                        return true;
                    }
                }
            }
            catch
            {
            }

            flag = default;
            return false;
        }

        private static bool TryGetOperationalLogicFlag(out Operational.Flag flag)
        {
            // The enum member name has differed between ONI versions.
            // We avoid hard-coding a specific member like Operational.Flag.Logic.

            var flagType = typeof(Operational.Flag);

            string[] preferredNames = new[]
            {
                "Logic",
                "Automation",
                "Automated",
                "LogicCircuit",
                "AutomationInput",
            };

            foreach (var name in preferredNames)
            {
                try
                {
                    if (Enum.IsDefined(flagType, name))
                    {
                        flag = (Operational.Flag)Enum.Parse(flagType, name, ignoreCase: false);
                        return true;
                    }
                }
                catch
                {
                }
            }

            try
            {
                foreach (var name in Enum.GetNames(flagType))
                {
                    if (string.IsNullOrEmpty(name))
                        continue;

                    if (name.IndexOf("Logic", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        name.IndexOf("Automation", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        flag = (Operational.Flag)Enum.Parse(flagType, name, ignoreCase: true);
                        return true;
                    }
                }
            }
            catch
            {
            }

            flag = default;
            return false;
        }

        protected void TryForceUnobtaniumForBuildable()
        {
            // Ensure the final constructed building cannot melt.
            try
            {
                if (!IsBuildableSatellite())
                    return;

                if (primaryElement == null)
                    return;

                if (primaryElement.ElementID == SimHashes.Unobtanium)
                    return;

                var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
                var element = ElementLoader.FindElementByHash(SimHashes.Unobtanium);

                // Prefer SetElement overloads so cached Element references stay consistent.
                foreach (var mi in typeof(PrimaryElement).GetMethods(flags))
                {
                    if (!string.Equals(mi.Name, "SetElement", StringComparison.Ordinal))
                        continue;

                    var ps = mi.GetParameters();
                    if (ps == null || ps.Length != 1)
                        continue;

                    var pt = ps[0].ParameterType;

                    if (pt == typeof(SimHashes))
                    {
                        mi.Invoke(primaryElement, new object[] { SimHashes.Unobtanium });
                        return;
                    }

                    if (pt == typeof(int))
                    {
                        mi.Invoke(primaryElement, new object[] { (int)SimHashes.Unobtanium });
                        return;
                    }

                    if (element != null)
                    {
                        if (pt == typeof(Element))
                        {
                            mi.Invoke(primaryElement, new object[] { element });
                            return;
                        }

                        if (pt == typeof(Tag))
                        {
                            mi.Invoke(primaryElement, new object[] { element.tag });
                            return;
                        }
                    }
                }

                // Fallback: set common fields/properties directly.
                if (element != null)
                {
                    var fElement = typeof(PrimaryElement).GetField("element", flags) ?? typeof(PrimaryElement).GetField("Element", flags);
                    if (fElement != null && fElement.FieldType == typeof(Element))
                        fElement.SetValue(primaryElement, element);

                    var pElement = typeof(PrimaryElement).GetProperty("Element", flags);
                    if (pElement != null && pElement.CanWrite && pElement.PropertyType == typeof(Element))
                        pElement.SetValue(primaryElement, element, null);
                }

                SetElementIdMember(typeof(PrimaryElement), primaryElement, "ElementID", SimHashes.Unobtanium, flags);
                SetElementIdMember(typeof(PrimaryElement), primaryElement, "elementID", SimHashes.Unobtanium, flags);
            }
            catch
            {
                // ignored
            }
        }



        protected void TryOverrideOverheatTemperature(float overheatTempK)
        {
            try
            {
                Overheatable overheatable = GetComponent<Overheatable>();
                if (overheatable == null)
                    return;

                Type t = overheatable.GetType();
                BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

                bool any = false;

                // Common field/property names across ONI versions.
                string[] names = new[]
                {
                    "overheatTemperature",
                    "overheatTemp",
                    "OverheatTemperature",
                    "overHeatTemperature",
                    "baseOverheatTemperature",
                    "baseOverheatTemp"
                };

                foreach (string name in names)
                {
                    PropertyInfo p = t.GetProperty(name, flags);
                    if (p != null && p.CanWrite && p.PropertyType == typeof(float))
                    {
                        try
                        {
                            p.SetValue(overheatable, overheatTempK, null);
                            any = true;
                        }
                        catch { }
                    }

                    FieldInfo f = t.GetField(name, flags);
                    if (f != null && f.FieldType == typeof(float))
                    {
                        try
                        {
                            f.SetValue(overheatable, overheatTempK);
                            any = true;
                        }
                        catch { }
                    }
                }

                // If there is a setter method, call it as well.
                try
                {
                    MethodInfo m = t.GetMethod("SetOverheatTemperature", flags, null, new[] { typeof(float) }, null);
                    if (m != null)
                    {
                        m.Invoke(overheatable, new object[] { overheatTempK });
                        any = true;
                    }
                }
                catch { }

                // If nothing matched, do nothing silently.
                if (!any)
                    return;
            }
            catch
            {
                // ignored
            }
        }

        private static void SetElementIdMember(Type type, object instance, string memberName, SimHashes hash, BindingFlags flags)
        {
            if (type == null || instance == null || string.IsNullOrEmpty(memberName))
                return;

            try
            {
                var prop = type.GetProperty(memberName, flags);
                if (prop != null && prop.CanWrite)
                {
                    TryAssignElementId(prop.PropertyType, v => prop.SetValue(instance, v, null), hash);
                    return;
                }

                var field = type.GetField(memberName, flags);
                if (field != null)
                {
                    TryAssignElementId(field.FieldType, v => field.SetValue(instance, v), hash);
                }
            }
            catch
            {
                // ignored
            }
        }

        private static void TryAssignElementId(Type memberType, Action<object> setter, SimHashes hash)
        {
            if (memberType == null || setter == null)
                return;

            try
            {
                if (memberType == typeof(SimHashes)) { setter(hash); return; }

                int i = (int)hash;
                if (memberType == typeof(int)) { setter(i); return; }
                if (memberType == typeof(short)) { setter((short)i); return; }
                if (memberType == typeof(ushort)) { setter((ushort)i); return; }
                if (memberType == typeof(byte)) { setter((byte)i); return; }
                if (memberType == typeof(sbyte)) { setter((sbyte)i); return; }

                if (memberType.IsEnum)
                {
                    setter(Enum.ToObject(memberType, i));
                }
            }
            catch
            {
                // ignored
            }
        }

        protected bool IsFullyOperational()
        {
            if (operational == null) return true;
            try
            {
                return operational.IsOperational;
            }
            catch
            {
                object r = ReflectionUtil.TryCall(operational, "IsOperational");
                if (r is bool b) return b;
                return true;
            }
        }

        protected void SetLight(Light2D light, bool on, float lux)
        {
            if (light == null) return;

            light.enabled = on;
            // Light2D.Lux is int in some ONI builds; assign an int to compile across versions.
            light.Lux = on ? Mathf.RoundToInt(lux) : 0;

            TryRefreshLight(light);
        }

        private static void TryRefreshLight(Light2D light)
        {
            if (light == null) return;

            // Some ONI builds require a refresh call before the light contributes to the lighting grid.
            try
            {
                var t = light.GetType();
                string[] methodNames =
                {
                    "RefreshShape",
                    "UpdateLitCells",
                    "Refresh",
                    "UpdateLight",
                    "MarkDirty"
                };

                foreach (var name in methodNames)
                {
                    var mi = t.GetMethod(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (mi == null) continue;
                    if (mi.GetParameters().Length != 0) continue;
                    mi.Invoke(light, null);
                }
            }
            catch
            {
                // ignore
            }
        }

        protected void AddHeatToSelf(float heatKDTUPerSecond, float dt)
        {
            if (primaryElement == null) return;
            if (heatKDTUPerSecond <= 0f) return;

            float dtu = heatKDTUPerSecond * 1000f * dt;

            try
            {
                MethodInfo mi = typeof(PrimaryElement).GetMethod("AddEnergy", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (mi != null)
                {
                    var ps = mi.GetParameters();
                    if (ps.Length == 1 && ps[0].ParameterType == typeof(float))
                    {
                        mi.Invoke(primaryElement, new object[] { dtu });
                        return;
                    }
                    if (ps.Length == 2 && ps[0].ParameterType == typeof(float))
                    {
                        mi.Invoke(primaryElement, new object[] { dtu, false });
                        return;
                    }
                }
            }
            catch
            {
            }

            // Last resort: temperature delta
            try
            {
                float mass = primaryElement.Mass;
                float shc = primaryElement.Element.specificHeatCapacity;
                if (mass > 0f && shc > 0f)
                {
                    float dT = dtu / (mass * shc);
                    primaryElement.Temperature += dT;
                }
            }
            catch
            {
            }
        }
    }
}
