using System;
using KSerialization;
using NewBuildableCrashedSatellite.Utils;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    [SerializationConfig(MemberSerialization.OptIn)]
    internal sealed class CrushedSatelliteRangeSettings : KMonoBehaviour
    {
        [Serialize]
        public int extendLeft;

        [Serialize]
        public int extendRight;

        [Serialize]
        public int extendUp;

        private int pendingLeft;
        private int pendingRight;
        private int pendingUp;

        private CrushedSatelliteController controller;

        protected override void OnSpawn()
        {
            base.OnSpawn();

            controller = GetComponent<CrushedSatelliteController>();

            pendingLeft = extendLeft;
            pendingRight = extendRight;
            pendingUp = extendUp;

            Subscribe((int)GameHashes.RefreshUserMenu, OnRefreshUserMenu);
        }

        public int WidthApplied => SatelliteTuning.CRUSHED_BASE_WIDTH + extendLeft + extendRight;
        public int HeightApplied => SatelliteTuning.CRUSHED_BASE_HEIGHT + extendUp;

        public int WidthPending => SatelliteTuning.CRUSHED_BASE_WIDTH + pendingLeft + pendingRight;
        public int HeightPending => SatelliteTuning.CRUSHED_BASE_HEIGHT + pendingUp;

        private void ClampPending()
        {
            pendingLeft = Mathf.Clamp(pendingLeft, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);
            pendingRight = Mathf.Clamp(pendingRight, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);
            pendingUp = Mathf.Clamp(pendingUp, 0, SatelliteTuning.CRUSHED_MAX_EXTEND);
        }

        private void ApplyPendingToSaved()
        {
            ClampPending();
            extendLeft = pendingLeft;
            extendRight = pendingRight;
            extendUp = pendingUp;

            if (controller != null)
                controller.OnRangeSettingsApplied();
        }

        private void ResetAll(bool applyImmediately)
        {
            pendingLeft = 0;
            pendingRight = 0;
            pendingUp = 0;

            if (applyImmediately)
                ApplyPendingToSaved();

            RequestUserMenuRefresh();
        }

        private void RequestUserMenuRefresh()
        {
            try
            {
                if (Game.Instance != null && Game.Instance.userMenu != null)
                    Game.Instance.userMenu.Refresh(gameObject);
            }
            catch
            {
            }
        }

        private void OnRefreshUserMenu(object data)
        {
            try
            {
                if (Game.Instance == null || Game.Instance.userMenu == null)
                    return;

				var headerObj = ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("Radiation Area: {0}x{1} (pending {2}x{3})", WidthApplied, HeightApplied, WidthPending, HeightPending),
					onClick: () => { },
					tooltipText: "Crushed Satellite radiation rectangle settings"
				);
				var header = (KIconButtonMenu.ButtonInfo)headerObj;
	                header.isInteractable = false;
	                Game.Instance.userMenu.AddButton(gameObject, header);

                // Left +/-
				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("←  +1 (L={0})", pendingLeft),
					onClick: () => { pendingLeft++; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Extend area to the left (+1)"
				));

				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("→  -1 (L={0})", pendingLeft),
					onClick: () => { pendingLeft--; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Reduce left extension (-1)"
				));

                // Right +/-
				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("→  +1 (R={0})", pendingRight),
					onClick: () => { pendingRight++; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Extend area to the right (+1)"
				));

				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("←  -1 (R={0})", pendingRight),
					onClick: () => { pendingRight--; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Reduce right extension (-1)"
				));

                // Up +/-
				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("↑  +1 (U={0})", pendingUp),
					onClick: () => { pendingUp++; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Extend area upward (+1)"
				));

				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: string.Format("↓  -1 (U={0})", pendingUp),
					onClick: () => { pendingUp--; ClampPending(); RequestUserMenuRefresh(); },
					tooltipText: "Reduce upward extension (-1)"
				));

                // Apply / Reset
				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: "Apply",
					onClick: () => { ApplyPendingToSaved(); RequestUserMenuRefresh(); },
					tooltipText: "Apply pending values"
				));

				Game.Instance.userMenu.AddButton(gameObject, (KIconButtonMenu.ButtonInfo)ButtonInfoUtil.Create(
					iconName: "action_mirror",
					text: "Reset",
					onClick: () => { ResetAll(applyImmediately: true); },
					tooltipText: "Reset to 6x6 and apply"
				));
            }
            catch (Exception e)
            {
                Debug.LogError("[NewBuildableCrashedSatellite] CrushedSatelliteRangeSettings user menu error: " + e);
            }
        }
    }
}
