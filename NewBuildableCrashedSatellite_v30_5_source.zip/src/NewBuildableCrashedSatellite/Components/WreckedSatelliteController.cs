using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    internal sealed class WreckedSatelliteController : SatelliteControllerBase
    {
        private RadiationEmitter emitter;
        private Light2D light;

        
        protected override void OnSpawn()
        {
            base.OnSpawn();

            // Force Neutronium (prevents melting / material-based radiation side effects).
            TryForceUnobtaniumForBuildable();
            EnsureEnergyConsumerWatts(SatelliteTuning.WRECKED_POWER_WATTS);

            // Force the requested overheat temperature (some ONI versions can ignore BuildingDef changes).
            TryOverrideOverheatTemperature(SatelliteTuning.WRECKED_OVERHEAT_TEMP_K);

            emitter = GetComponent<RadiationEmitter>();
            NormalizeEmitterForBuildable(emitter);

            light = GetComponent<Light2D>();
            if (emitter != null && light != null)
            {
                float rx = emitter.emitRadiusX;
                float ry = emitter.emitRadiusY;
                light.Range = Mathf.Max(rx, ry);
            }

            ApplyState(enabledOverride: true, poweredMode: false, dt: 0f);
        }

        
        protected override void Sim1000msImpl(float dt)
        {
            bool tempOk = TemperatureGate(SatelliteTuning.WRECKED_STOP_C);
            bool automationSignalOn = IsAutomationSignalOn();
            bool powerSatisfied = IsPoweredSatisfied();

            // Always request power while the satellite is permitted to run (temperature OK).
            // This ensures the building actually draws watts when connected to a powered circuit.
            TrySetOperationalActive(tempOk);

            bool enabled;
            bool poweredMode;

            if (!tempOk)
            {
                enabled = false;
                poweredMode = false;
            }
            else if (powerSatisfied)
            {
                // Automation ON/OFF only applies when power is satisfied.
                enabled = automationSignalOn;
                poweredMode = enabled; // Powered effects only while enabled.
            }
            else
            {
                // Base mode: always on (automation ignored).
                enabled = true;
                poweredMode = false;
            }

            ApplyState(enabled, poweredMode, dt);
        }

        private void ApplyState(bool enabledOverride, bool poweredMode, float dt)
        {
            if (emitter != null)
            {
                emitter.enabled = enabledOverride;
                emitter.emitRads = enabledOverride ? SatelliteTuning.WRECKED_RADS_PER_CYCLE : 0f;
            }

            if (!enabledOverride)
            {
                if (light != null)
                    SetLight(light, false, SatelliteTuning.WRECKED_POWERED_LUX);
                return;
            }

            float heatKDTU = poweredMode ? SatelliteTuning.WRECKED_HEAT_POWERED_KDTU_PER_S : SatelliteTuning.WRECKED_HEAT_BASE_KDTU_PER_S;
            AddHeatToSelf(heatKDTU, dt);

            if (light != null)
                SetLight(light, poweredMode, SatelliteTuning.WRECKED_POWERED_LUX);
        }
    }
}
