using UnityEngine;

namespace NewBuildableCrashedSatellite.Components
{
    /// <summary>
    /// Provides a secondary conduit output offset (e.g. a gas output port alongside a primary liquid output).
    /// </summary>
    internal sealed class SatelliteSecondaryOutput : KMonoBehaviour, ISecondaryOutput
    {
        public CellOffset gasOutputOffset = new CellOffset(0, 0);

        /// <summary>
        /// Returns true if this component provides a secondary conduit output for the given conduit type.
        /// ONI's conduit components query ISecondaryOutput via HasSecondaryConduitType(...) before calling
        /// GetSecondaryConduitOffset(...).
        /// </summary>
        public bool HasSecondaryConduitType(ConduitType outputConduitType)
        {
            // This mod only uses a secondary *gas* output port.
            return outputConduitType == ConduitType.Gas;
        }

        public CellOffset GetSecondaryConduitOffset(ConduitType outputConduitType)
        {
            if (outputConduitType == ConduitType.Gas)
                return gasOutputOffset;

            // Only gas is supported as a secondary output for this mod.
            return new CellOffset(0, 0);
        }
    }
}
