using System;
using NewBuildableCrashedSatellite.Patches;
using TUNING;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Buildings
{
    /// <summary>
    /// Buildable version of the vanilla (worldgen) Wrecked Satellite (PropSurfaceSatellite2).
    /// </summary>
    public sealed class BuildableWreckedSatelliteConfig : IBuildingConfig
    {
        public const string ID = SatelliteIds.BUILDABLE_WRECKED;

        [Obsolete("BuildingConfig.GetDlcIds is obsolete on current ONI builds. DLC restriction is enforced via mod_info.yaml (requiredDlcIds).", false)]
        public override string[] GetDlcIds() => new string[] { DlcManager.EXPANSION1_ID };

        public override BuildingDef CreateBuildingDef()
        {
            var recipe = SatelliteTuning.GetRecipe(ID);
            string anim =
                SatellitePatcher.TryGetKanimNameFromVanillaConfig("PropSurfaceSatellite2Config") ??
                SatellitePatcher.TryGetKanimNameFromVanillaPrefab(SatelliteIds.WRECKED) ??
                SatellitePatcher.FallbackKanim;

            BuildingDef def = BuildingTemplates.CreateBuildingDef(
                ID,
                width: 4,
                height: 4,
                anim: anim,
                hitpoints: 60,
                construction_time: 180f,
                construction_mass: recipe.Masses,
                construction_materials: recipe.Materials,
                melting_point: 8000f,
                build_location_rule: BuildLocationRule.NotInTiles,
                decor: BUILDINGS.DECOR.NONE,
                noise: NOISE_POLLUTION.NONE);

            SatellitePatcher.ConfigureBuildingDef(def);
            return def;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefabTag)
        {
            // nothing
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            SatellitePatcher.TryInvokeBuildingTemplatesDoPostConfigure(go);
            SatellitePatcher.ConfigurePrefab(go);
        }
}
}
