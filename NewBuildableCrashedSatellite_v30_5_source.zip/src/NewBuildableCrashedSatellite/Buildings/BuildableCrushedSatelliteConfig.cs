using System;
using NewBuildableCrashedSatellite.Patches;
using TUNING;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Buildings
{
    /// <summary>
    /// Buildable version of the vanilla (worldgen) Crushed Satellite (PropSurfaceSatellite3).
    /// </summary>
    public sealed class BuildableCrushedSatelliteConfig : IBuildingConfig
    {
        public const string ID = SatelliteIds.BUILDABLE_CRUSHED;

        [Obsolete("BuildingConfig.GetDlcIds is obsolete on current ONI builds. DLC restriction is enforced via mod_info.yaml (requiredDlcIds).", false)]
        public override string[] GetDlcIds() => new string[] { DlcManager.EXPANSION1_ID };

        public override BuildingDef CreateBuildingDef()
        {
            var recipe = SatelliteTuning.GetRecipe(ID);
            string anim =
                SatellitePatcher.TryGetKanimNameFromVanillaConfig("PropSurfaceSatellite3Config") ??
                SatellitePatcher.TryGetKanimNameFromVanillaPrefab(SatelliteIds.CRUSHED) ??
                SatellitePatcher.FallbackKanim;

            BuildingDef def = BuildingTemplates.CreateBuildingDef(
                ID,
                width: 6,
                height: 6,
                anim: anim,
                hitpoints: 120,
                construction_time: 300f,
                construction_mass: recipe.Masses,
                construction_materials: recipe.Materials,
                melting_point: 8000f,
                build_location_rule: BuildLocationRule.NotInTiles,
                decor: BUILDINGS.DECOR.NONE,
                noise: NOISE_POLLUTION.NONE);

            SatellitePatcher.ConfigureBuildingDef(def);
            return def;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefabTag)
        {
            // nothing
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            SatellitePatcher.TryInvokeBuildingTemplatesDoPostConfigure(go);
            SatellitePatcher.ConfigurePrefab(go);
        }
}
}
