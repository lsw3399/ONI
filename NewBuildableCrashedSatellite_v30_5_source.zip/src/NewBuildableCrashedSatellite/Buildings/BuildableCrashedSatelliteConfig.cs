using System;
using NewBuildableCrashedSatellite.Patches;
using TUNING;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Buildings
{
    /// <summary>
    /// Buildable version of the vanilla (worldgen) Crashed Satellite (PropSurfaceSatellite1).
    /// Uses the vanilla kanim (resolved at runtime) and the NBCS tuning/components.
    /// </summary>
    public sealed class BuildableCrashedSatelliteConfig : IBuildingConfig
    {
        public const string ID = SatelliteIds.BUILDABLE_CRASHED;

        [Obsolete("BuildingConfig.GetDlcIds is obsolete on current ONI builds. DLC restriction is enforced via mod_info.yaml (requiredDlcIds).", false)]
        public override string[] GetDlcIds() => new string[] { DlcManager.EXPANSION1_ID };

        public override BuildingDef CreateBuildingDef()
        {
            var recipe = SatelliteTuning.GetRecipe(ID);
            string anim =
                SatellitePatcher.TryGetKanimNameFromVanillaConfig("PropSurfaceSatellite1Config") ??
                SatellitePatcher.TryGetKanimNameFromVanillaPrefab(SatelliteIds.CRASHED) ??
                SatellitePatcher.FallbackKanim;

            BuildingDef def = BuildingTemplates.CreateBuildingDef(
                ID,
                width: 3,
                height: 3,
                anim: anim,
                hitpoints: 30,
                construction_time: 120f,
                construction_mass: recipe.Masses,
                construction_materials: recipe.Materials,
                melting_point: 8000f,
                build_location_rule: BuildLocationRule.NotInTiles,
                decor: BUILDINGS.DECOR.NONE,
                noise: NOISE_POLLUTION.NONE);

            SatellitePatcher.ConfigureBuildingDef(def);
            return def;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefabTag)
        {
            // Nothing special; SatellitePatcher.ConfigurePrefab adds NBCS components.
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            // ONI builds differ: some have BuildingTemplates.DoPostConfigure(go), some do not.
            // Call it via reflection when available to avoid compile errors.
            SatellitePatcher.TryInvokeBuildingTemplatesDoPostConfigure(go);

            // Configure prefab (controllers, remove rummage/inspect, deconstruct drops, etc.)
            SatellitePatcher.ConfigurePrefab(go);
        }
}
}
