using System;
using System.Linq;
using System.Reflection;

namespace NewBuildableCrashedSatellite.Utils
{
    internal static class ReflectionUtil
    {
        internal static FieldInfo FindField(Type type, params string[] names)
        {
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            foreach (var n in names)
            {
                var fi = type.GetField(n, flags);
                if (fi != null) return fi;
            }
            return null;
        }

        internal static PropertyInfo FindProperty(Type type, params string[] names)
        {
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            foreach (var n in names)
            {
                var pi = type.GetProperty(n, flags);
                if (pi != null) return pi;
            }
            return null;
        }

        internal static bool TryGetBool(object target, out bool value, params string[] memberNames)
        {
            value = false;
            if (target == null) return false;
            var type = target.GetType();
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

            foreach (var name in memberNames)
            {
                var fi = type.GetField(name, flags);
                if (fi != null)
                {
                    var v = fi.GetValue(target);
                    if (v is bool b)
                    {
                        value = b;
                        return true;
                    }
                }
                var pi = type.GetProperty(name, flags);
                if (pi != null && pi.CanRead)
                {
                    var v = pi.GetValue(target, null);
                    if (v is bool b)
                    {
                        value = b;
                        return true;
                    }
                }
            }
            return false;
        }

        internal static object TryCall(object target, string methodName, params object[] args)
        {
            if (target == null) return null;
            var type = target.GetType();
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

            var methods = type.GetMethods(flags).Where(m => m.Name == methodName).ToArray();
            foreach (var m in methods)
            {
                var ps = m.GetParameters();
                if (ps.Length != args.Length) continue;

                bool ok = true;
                for (int i = 0; i < ps.Length; i++)
                {
                    var pt = ps[i].ParameterType;
                    var av = args[i];
                    if (av == null)
                    {
                        if (pt.IsValueType && Nullable.GetUnderlyingType(pt) == null) { ok = false; break; }
                    }
                    else if (!pt.IsInstanceOfType(av))
                    {
                        ok = false;
                        break;
                    }
                }
                if (!ok) continue;

                return m.Invoke(target, args);
            }

            return null;
        }
    }
}
