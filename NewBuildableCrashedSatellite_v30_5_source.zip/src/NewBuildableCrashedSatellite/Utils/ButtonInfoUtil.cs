using System;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using STRINGS;

namespace NewBuildableCrashedSatellite.Utils
{
    internal static class ButtonInfoUtil
    {
        private const BindingFlags FLAGS = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        internal static object Create(string iconName, string text, System.Action onClick, string tooltipText)
        {
            var t = typeof(KIconButtonMenu.ButtonInfo);

            object boxed = null;
            try
            {
                boxed = Activator.CreateInstance(t, true);
            }
            catch
            {
                try
                {
                    boxed = FormatterServices.GetUninitializedObject(t);
                }
                catch
                {
                    // As a last resort, try to find any compatible ctor.
                    boxed = TryInvokeAnyConstructor(t, iconName, text, onClick, tooltipText);
                    if (boxed == null)
                        throw;
                }
            }

            // Fill common fields/properties by name.
            TrySetString(boxed, new[] { "iconName", "icon", "spriteName", "icon_name" }, iconName);
            TrySetLocString(boxed, new[] { "text", "label", "title" }, text);
            TrySetLocString(boxed, new[] { "tooltipText", "tooltip", "toolTip", "tooltip_text" }, tooltipText);
            TrySetAction(boxed, new[] { "onClick", "on_click", "action", "callback" }, onClick);

            // Optional: shortcut key (avoid unbound actions where possible).
            TrySetShortcutKey(boxed);

            TryForceEnabled(boxed);

            return boxed;
        }

        private static object TryInvokeAnyConstructor(Type t, string iconName, string text, System.Action onClick, string tooltipText)
        {
            try
            {
                foreach (var ctor in t.GetConstructors(FLAGS))
                {
                    var ps = ctor.GetParameters();
                    var args = new object[ps.Length];
                    bool ok = true;

                    for (int i = 0; i < ps.Length; i++)
                    {
                        var pt = ps[i].ParameterType;
                        if (pt == typeof(string))
                        {
                            // Heuristic: first string is icon, second is text, third is tooltip.
                            if (args.Count(a => a is string) == 0)
                                args[i] = iconName;
                            else if (args.Count(a => a is string) == 1)
                                args[i] = text;
                            else
                                args[i] = tooltipText;
                        }
                        else if (typeof(Delegate).IsAssignableFrom(pt))
                        {
                            args[i] = CreateOnClickDelegate(pt, onClick);
                        }
                        else if (pt.FullName == "STRINGS.LocString" || pt == typeof(LocString))
                        {
                            // Prefer mapping by order: text then tooltip.
                            if (args.Any(a => a is LocString))
                                args[i] = (LocString)tooltipText;
                            else
                                args[i] = (LocString)text;
                        }
                        else if (pt.IsEnum && pt.Name == "Action")
                        {
                            // ShortcutKey
                            args[i] = GetSafeShortcutKey(pt);
                        }
                        else
                        {
                            // Unhandled parameter type; skip this ctor.
                            ok = false;
                            break;
                        }
                    }

                    if (!ok)
                        continue;

                    return ctor.Invoke(args);
                }
            }
            catch
            {
            }

            return null;
        }

        private static void TrySetString(object target, string[] names, string value)
        {
            if (target == null || names == null)
                return;

            foreach (var name in names)
            {
                if (TrySetMember(target, name, typeof(string), value))
                    return;
            }
        }

        private static void TrySetLocString(object target, string[] names, string value)
        {
            if (target == null || names == null)
                return;

            foreach (var name in names)
            {
                // Most builds use LocString
                if (TrySetMember(target, name, typeof(LocString), (LocString)value))
                    return;

                // Some builds may use string
                if (TrySetMember(target, name, typeof(string), value))
                    return;
            }
        }

        private static void TrySetAction(object target, string[] names, System.Action value)
        {
            if (target == null || names == null)
                return;

            foreach (var name in names)
            {
                try
                {
                    var member = target.GetType().GetMember(name, FLAGS).FirstOrDefault();
                    if (member == null)
                        continue;

                    Type memberType = null;
                    if (member is FieldInfo f)
                        memberType = f.FieldType;
                    else if (member is PropertyInfo p)
                        memberType = p.PropertyType;

                    if (memberType == null || !typeof(Delegate).IsAssignableFrom(memberType))
                        continue;

                    object del = CreateOnClickDelegate(memberType, value);
                    if (del == null)
                        continue;

                    if (member is FieldInfo ff)
                    {
                        if (memberType.IsAssignableFrom(del.GetType()))
                        {
                            ff.SetValue(target, del);
                            return;
                        }
                    }
                    else if (member is PropertyInfo pp && pp.CanWrite)
                    {
                        if (memberType.IsAssignableFrom(del.GetType()))
                        {
                            pp.SetValue(target, del, null);
                            return;
                        }
                    }
                }
                catch
                {
                    // ignore
                }
            }
        }

        private static object CreateOnClickDelegate(Type delegateType, System.Action onClick)
        {
            if (delegateType == null || onClick == null)
                return null;

            try
            {
                if (delegateType == typeof(System.Action))
                    return onClick;

                if (delegateType.IsGenericType)
                {
                    var def = delegateType.GetGenericTypeDefinition();
                    var ga = delegateType.GetGenericArguments();

                    if (def == typeof(System.Action<>) && ga.Length == 1)
                    {
                        var m = typeof(ButtonInfoUtil).GetMethod(nameof(WrapAction1), BindingFlags.NonPublic | BindingFlags.Static);
                        return m?.MakeGenericMethod(ga[0]).Invoke(null, new object[] { onClick });
                    }

                    if (def == typeof(System.Action<,>) && ga.Length == 2)
                    {
                        var m = typeof(ButtonInfoUtil).GetMethod(nameof(WrapAction2), BindingFlags.NonPublic | BindingFlags.Static);
                        return m?.MakeGenericMethod(ga[0], ga[1]).Invoke(null, new object[] { onClick });
                    }
                }
            }
            catch
            {
                // ignore
            }

            return null;
        }

        private static System.Action<T> WrapAction1<T>(System.Action onClick)
        {
            return _ => onClick();
        }

        private static System.Action<T1, T2> WrapAction2<T1, T2>(System.Action onClick)
        {
            return (_, __) => onClick();
        }

        private static void TrySetShortcutKey(object target)
        {
            if (target == null)
                return;

            // Try common member names.
            string[] names = { "shortcutKey", "shortcut", "hotkey", "action" };

            foreach (var name in names)
            {
                // Field/property type is the game's Action enum.
                var member = target.GetType().GetMember(name, FLAGS).FirstOrDefault();
                if (member == null)
                    continue;

                Type t = null;
                if (member is FieldInfo f)
                    t = f.FieldType;
                else if (member is PropertyInfo p)
                    t = p.PropertyType;

                if (t == null || !t.IsEnum)
                    continue;

                object v = GetSafeShortcutKey(t);
                try
                {
                    if (member is FieldInfo ff)
                    {
                        ff.SetValue(target, v);
                        return;
                    }
                    if (member is PropertyInfo pp && pp.CanWrite)
                    {
                        pp.SetValue(target, v, null);
                        return;
                    }
                }
                catch
                {
                }
            }
        }

        private static object GetSafeShortcutKey(Type actionEnumType)
        {
            // Prefer well-known sentinels if present.
            foreach (var name in new[] { "None", "NumActions", "MaxAction" })
            {
                try
                {
                    if (Enum.IsDefined(actionEnumType, name))
                        return Enum.Parse(actionEnumType, name);
                }
                catch
                {
                }
            }

            // Fallback to 0.
            try
            {
                return Enum.ToObject(actionEnumType, 0);
            }
            catch
            {
                return null;
            }
        }

        private static bool TrySetMember(object target, string name, Type expectedType, object value)
        {
            if (target == null || string.IsNullOrEmpty(name))
                return false;

            try
            {
                var f = target.GetType().GetField(name, FLAGS);
                if (f != null && expectedType.IsAssignableFrom(f.FieldType))
                {
                    f.SetValue(target, value);
                    return true;
                }

                var p = target.GetType().GetProperty(name, FLAGS);
                if (p != null && p.CanWrite && expectedType.IsAssignableFrom(p.PropertyType))
                {
                    p.SetValue(target, value, null);
                    return true;
                }
            }
            catch
            {
            }

            return false;
        }

        private static readonly Func<bool> AlwaysTrueFn = () => true;

        /// <summary>
        /// Some ONI builds use an isEnabled delegate (e.g. isEnabledFn) inside ButtonInfo.
        /// If we leave it null, the button can become non-interactable. Force-enable it.
        /// </summary>
        private static void TryForceEnabled(object buttonInfo)
        {
            if (buttonInfo == null)
                return;

            try
            {
                var t = buttonInfo.GetType();
                const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

                // Common bool toggles
                string[] boolNames = {
                    "isEnabled",
                    "IsEnabled",
                    "enabled",
                    "Enabled",
                    "interactable",
                    "Interactable",
                    "isInteractable",
                    "IsInteractable",
                };

                // Common delegates returning bool
                string[] funcNames = {
                    "isEnabledFn",
                    "IsEnabledFn",
                    "isEnabledFunc",
                    "IsEnabledFunc",
                    "enabledFn",
                    "EnabledFn",
                    "isActiveFn",
                    "IsActiveFn",
                    "isAvailableFn",
                    "IsAvailableFn",
                };

                foreach (var n in boolNames)
                {
                    if (string.IsNullOrEmpty(n))
                        continue;

                    var f = t.GetField(n, Flags);
                    if (f != null && f.FieldType == typeof(bool))
                    {
                        f.SetValue(buttonInfo, true);
                    }

                    var p = t.GetProperty(n, Flags);
                    if (p != null && p.CanWrite && p.PropertyType == typeof(bool))
                    {
                        p.SetValue(buttonInfo, true, null);
                    }
                }

                foreach (var n in funcNames)
                {
                    if (string.IsNullOrEmpty(n))
                        continue;

                    var f = t.GetField(n, Flags);
                    if (f != null && f.FieldType == typeof(Func<bool>))
                    {
                        f.SetValue(buttonInfo, AlwaysTrueFn);
                    }

                    var p = t.GetProperty(n, Flags);
                    if (p != null && p.CanWrite && p.PropertyType == typeof(Func<bool>))
                    {
                        p.SetValue(buttonInfo, AlwaysTrueFn, null);
                    }
                }
            }
            catch
            {
            }
        }

    }
}
