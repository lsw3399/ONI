using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace NewBuildableCrashedSatellite
{
    internal static class LocalizationHelper
    {
        private static bool englishRegistered;
        private static string appliedLocale;

        private static bool IsKoreanLocale(string code)
        {
            if (string.IsNullOrEmpty(code))
                return false;

            var c = code.Trim().ToLowerInvariant();
            // ONI/Steam locale codes seen in the wild: ko-KR, ko_KR, ko, korean, koreana
            return c == "ko" || c.StartsWith("ko-") || c.StartsWith("ko_") ||
                   c.Contains("korean") || c.Contains("koreana");
        }

        private static List<string> BuildLocaleCandidates(string rawCode)
        {
            var list = new List<string>();
            if (string.IsNullOrWhiteSpace(rawCode))
                return list;

            void Add(string s)
            {
                if (string.IsNullOrWhiteSpace(s))
                    return;
                if (!list.Contains(s))
                    list.Add(s);
            }

            var c = rawCode.Trim();
            Add(c);
            Add(c.ToLowerInvariant());
            Add(c.Replace('_', '-'));
            Add(c.Replace('-', '_'));

            // Base language token
            var baseCode = c;
            if (baseCode.IndexOf('-') >= 0)
                baseCode = baseCode.Split('-')[0];
            if (baseCode.IndexOf('_') >= 0)
                baseCode = baseCode.Split('_')[0];
            Add(baseCode);
            Add(baseCode.ToLowerInvariant());

            // Korean aliases
            if (IsKoreanLocale(c))
            {
                Add("ko");
                Add("ko-KR");
                Add("ko_KR");
                Add("koreana");
                Add("korean");
            }

            return list;
        }

        internal static void Init()
        {
            try
            {
                // Provide a complete English baseline (prevents MISSING.STRINGS... in non-Korean locales).
                if (!englishRegistered)
                {
                    RegisterEnglishStrings();
                    englishRegistered = true;
                }

                // Overload translations from "translations/<lang>.po" if present.
                string rawCode = null;
                try
                {
                    rawCode = Localization.GetLocale()?.Code;
                }
                catch
                {
                    // ignored
                }

                if (string.IsNullOrEmpty(rawCode))
                {
                    try
                    {
                        rawCode = Localization.GetCurrentLanguageCode();
                    }
                    catch
                    {
                        // ignored
                    }
                }

                if (string.IsNullOrEmpty(rawCode))
                    return;

                // Avoid re-applying the same locale multiple times.
                if (!string.IsNullOrEmpty(appliedLocale) && string.Equals(appliedLocale, rawCode, StringComparison.OrdinalIgnoreCase))
                    return;

                bool loaded = false;
                bool canLoadPo = !string.IsNullOrEmpty(ModAssets.ModPath) && Directory.Exists(ModAssets.ModPath);
                if (canLoadPo)
                {
                    foreach (var code in BuildLocaleCandidates(rawCode))
                    {
                    string poPath = Path.Combine(ModAssets.ModPath, "translations", code + ".po");
                    if (!File.Exists(poPath))
                        continue;

                    try
                    {
                        Localization.OverloadStrings(Localization.LoadStringsFile(poPath, false));
                        appliedLocale = rawCode;
                        loaded = true;
                        Debug.Log($"[NBCS] Loaded translations: {poPath}");
                        break;
                    }
                    catch (Exception e)
                    {
                        Debug.LogWarning($"[NBCS] Failed to load translations '{poPath}': {e}");
                    }
                }

                }

                

                if (!canLoadPo)
                {
                    Debug.LogWarning("[NBCS] ModPath not available; skipping .po load and using fallback strings when possible.");
                }

                // Apply Korean strings for Korean locales. This includes per-material tag strings used by
                // ConstructionMaterials (STRINGS.MISC.TAGS.*), which may not be present in .po files.
                if (IsKoreanLocale(rawCode))
                {
                    RegisterKoreanStrings();

                    if (!loaded)
                        Debug.Log("[NBCS] Applied Korean fallback strings (no .po loaded).");
                }

                // Mark locale as applied (even if no .po was loaded)
                appliedLocale = rawCode;

            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] Localization init failed: " + e);
            }
        }

        private static void RegisterEnglishStrings()
        {
            // Buildable satellites
            AddBuildingStrings(
                SatelliteIds.BUILDABLE_CRASHED,
                "Crashed Satellite",
                "A crashed satellite. It emits radiation.",
                "Emits 2000 rads of radiation per cycle into the surrounding area.");

            AddBuildingStrings(
                SatelliteIds.BUILDABLE_WRECKED,
                "Wrecked Satellite",
                "A wrecked satellite. It emits radiation.",
                "Emits 8000 rads of radiation per cycle into the surrounding area.\n" +
                "When supplied with power, it generates more heat, enables automation control, and emits light.");

            AddBuildingStrings(
                SatelliteIds.BUILDABLE_CRUSHED,
                "Crushed Satellite",
                "A crushed satellite. It emits radiation.",
                "Emits 10,000–60,000 rads of radiation per cycle into a controlled area.\n" +
                "When supplied with power, it generates more heat, enables automation control, increases radiation intensity, and emits light.\n" +
                "When supplied with power, it can also continuously extract Polluted Water and Natural Gas.");

            // Material tag display strings (used by multi-material build recipes / deconstruct preview)
            // NOTE: These are Tag keys (STRINGS.MISC.TAGS.*), not STRINGS.ELEMENTS.*.
            Strings.Add("STRINGS.MISC.TAGS.URANIUMORE", "Uranium Ore");
            Strings.Add("STRINGS.MISC.TAGS.TUNGSTEN", "Tungsten");
            Strings.Add("STRINGS.MISC.TAGS.COPPER", "Copper");
            Strings.Add("STRINGS.MISC.TAGS.IRON", "Iron");
            Strings.Add("STRINGS.MISC.TAGS.GOLD", "Gold");
            Strings.Add("STRINGS.MISC.TAGS.TITANIUM", "Titanium");
            Strings.Add("STRINGS.MISC.TAGS.TITANIUMORE", "Titanium Ore");
            Strings.Add("STRINGS.MISC.TAGS.STEEL", "Steel");
            Strings.Add("STRINGS.MISC.TAGS.PLASTIC", "Plastic");
            Strings.Add("STRINGS.MISC.TAGS.POLYPROPYLENE", "Plastic");
            Strings.Add("STRINGS.MISC.TAGS.DIAMOND", "Diamond");
            Strings.Add("STRINGS.MISC.TAGS.GLASS", "Glass");
            Strings.Add("STRINGS.MISC.TAGS.ENRICHEDURANIUM", "Enriched Uranium");
            Strings.Add("STRINGS.MISC.TAGS.TEMPCONDUCTORSOLID", "Thermium");
            Strings.Add("STRINGS.MISC.TAGS.HARDPOLYPROPYLENE", "Plastium");
        }

        private static void RegisterKoreanStrings()
        {
            // Buildable satellites
            AddBuildingStrings(
                SatelliteIds.BUILDABLE_CRASHED,
                "추락한 위성",
                "추락한 위성입니다. 방사선을 방출합니다.",
                "주변에 주기당 2000rads의 방사선을 방출합니다.");

            AddBuildingStrings(
                SatelliteIds.BUILDABLE_WRECKED,
                "파손된 위성",
                "파손된 위성입니다. 방사선을 방출합니다.",
                "주변에 주기당 8000rads의 방사선을 방출합니다.\n" +
                "전기가 연결될 경우, 열 발생량이 증가하고 자동화 제어가 가능해지며 빛을 방출합니다.");

            AddBuildingStrings(
                SatelliteIds.BUILDABLE_CRUSHED,
                "분쇄된 위성",
                "분쇄된 위성입니다. 통제된 범위에 강한 방사선을 방출합니다.",
                "통제된 범위에 주기당 10000~60000rads의 방사선을 방출합니다.\n" +
                "전기가 연결될 경우, 열 발생량이 증가하고 자동화 제어가 가능해지며 방사선 강도가 증가하고 빛을 방출합니다.\n" +
                "전기가 연결될 경우, 오염된 물과 천연가스를 지속적으로 추출할 수도 있습니다.");

            // Material tag display strings
            Strings.Add("STRINGS.MISC.TAGS.URANIUMORE", "우라늄 광석");
            Strings.Add("STRINGS.MISC.TAGS.TUNGSTEN", "텅스텐");
            Strings.Add("STRINGS.MISC.TAGS.COPPER", "구리");
            Strings.Add("STRINGS.MISC.TAGS.IRON", "철");
            Strings.Add("STRINGS.MISC.TAGS.GOLD", "금");
            Strings.Add("STRINGS.MISC.TAGS.TITANIUM", "티타늄");
            Strings.Add("STRINGS.MISC.TAGS.TITANIUMORE", "티타늄 광석");
            Strings.Add("STRINGS.MISC.TAGS.STEEL", "강철");
            Strings.Add("STRINGS.MISC.TAGS.PLASTIC", "플라스틱");
            Strings.Add("STRINGS.MISC.TAGS.POLYPROPYLENE", "플라스틱");
            Strings.Add("STRINGS.MISC.TAGS.DIAMOND", "다이아몬드");
            Strings.Add("STRINGS.MISC.TAGS.GLASS", "유리");
            Strings.Add("STRINGS.MISC.TAGS.ENRICHEDURANIUM", "농축 우라늄");
            Strings.Add("STRINGS.MISC.TAGS.TEMPCONDUCTORSOLID", "써미움");
            Strings.Add("STRINGS.MISC.TAGS.HARDPOLYPROPYLENE", "플라스튬");
        }

        private static void AddBuildingStrings(string id, string name, string desc, string effect)
        {
            if (string.IsNullOrEmpty(id))
                return;

            string key = id.ToUpperInvariant();
            Strings.Add($"STRINGS.BUILDINGS.PREFABS.{key}.NAME", name);
            Strings.Add($"STRINGS.BUILDINGS.PREFABS.{key}.DESC", desc);
            Strings.Add($"STRINGS.BUILDINGS.PREFABS.{key}.EFFECT", effect);
        }

        private static void AddEffectOnly(string id, string effect)
        {
            if (string.IsNullOrEmpty(id))
                return;
            string key = id.ToUpperInvariant();
            Strings.Add($"STRINGS.BUILDINGS.PREFABS.{key}.EFFECT", effect);
        }
    }
}
