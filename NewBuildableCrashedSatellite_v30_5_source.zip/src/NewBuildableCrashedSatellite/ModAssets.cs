using System;
using System.IO;

namespace NewBuildableCrashedSatellite
{
    /// <summary>
    /// Runtime mod assets/path cache.
    /// </summary>
    internal static class ModAssets
    {
        internal static string ModPath = "";

        internal static string TranslationsPath => Path.Combine(ModPath, "translations");

        internal static void Init(KMod.Mod mod)
        {
            // Prefer KMod-provided paths if possible, but validate that they actually point to the mod root.
            try
            {
                var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic;
                var t = mod?.GetType();

                if (t != null)
                {
                    // 1) Try common property names
                    foreach (var propName in new[] { "path", "Path", "ContentPath", "content_path", "ModPath", "modPath" })
                    {
                        var p = t.GetProperty(propName, flags);
                        if (p == null || p.PropertyType != typeof(string) || !p.CanRead)
                            continue;

                        var value = p.GetValue(mod, null) as string;
                        var root = FindModRoot(value);
                        if (!string.IsNullOrEmpty(root))
                        {
                            ModPath = root;
                            return;
                        }
                    }

                    // 2) Try common field names
                    foreach (var fieldName in new[] { "content_path", "ContentPath", "path", "Path", "modPath", "ModPath" })
                    {
                        var f = t.GetField(fieldName, flags);
                        if (f == null || f.FieldType != typeof(string))
                            continue;

                        var value = f.GetValue(mod) as string;
                        var root = FindModRoot(value);
                        if (!string.IsNullOrEmpty(root))
                        {
                            ModPath = root;
                            return;
                        }
                    }
                }
            }
            catch
            {
                // ignored
            }

            // 3) Reliable fallback: derive mod root from our DLL location
            try
            {
                string dllPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string dllDir = string.IsNullOrEmpty(dllPath) ? null : Path.GetDirectoryName(dllPath);

                var root = FindModRoot(dllDir);
                if (!string.IsNullOrEmpty(root))
                {
                    ModPath = root;
                    return;
                }
            }
            catch
            {
                // ignored
            }

            // Final fallback
            ModPath = ".";
        }

        /// <summary>
        /// Walk upward from <paramref name="start"/> until mod.yaml or mod_info.yaml is found.
        /// </summary>
        private static string FindModRoot(string start)
        {
            if (string.IsNullOrEmpty(start))
                return null;

            try
            {
                string dir = start;
                for (int i = 0; i < 8 && !string.IsNullOrEmpty(dir); i++)
                {
                    if (File.Exists(Path.Combine(dir, "mod.yaml")) || File.Exists(Path.Combine(dir, "mod_info.yaml")))
                        return dir;

                    var parent = Directory.GetParent(dir);
                    dir = parent?.FullName;
                }
            }
            catch
            {
                // ignored
            }

            return null;
        }
    }
}
