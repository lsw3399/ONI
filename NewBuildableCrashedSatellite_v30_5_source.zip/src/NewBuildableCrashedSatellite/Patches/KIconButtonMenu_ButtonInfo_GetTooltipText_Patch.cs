using System;
using System.Reflection;
using HarmonyLib;

namespace NewBuildableCrashedSatellite.Patches
{
    // Prevent rare crashes when a ButtonInfo has an unbound shortcut key (Action.Invalid, etc.)
    // and Klei's tooltip generator tries to resolve a hotkey binding.
    [HarmonyPatch(typeof(KIconButtonMenu.ButtonInfo), nameof(KIconButtonMenu.ButtonInfo.GetTooltipText))]
    internal static class KIconButtonMenu_ButtonInfo_GetTooltipText_Patch
    {
        internal static Exception Finalizer(KIconButtonMenu.ButtonInfo __instance, ref string __result, Exception __exception)
        {
            if (__exception is ArgumentException && __exception.Message != null && __exception.Message.Contains("GameInputBindings"))
            {
                __result = TryGetTooltipRaw(__instance) ?? string.Empty;
                return null; // swallow
            }

            return __exception;
        }

        private static string TryGetTooltipRaw(KIconButtonMenu.ButtonInfo info)
        {
            if (info == null)
                return null;

            try
            {
                var t = info.GetType();
                var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

                var f = t.GetField("tooltipText", flags) ?? t.GetField("tooltip", flags);
                if (f != null && f.FieldType == typeof(string))
                    return f.GetValue(info) as string;

                var p = t.GetProperty("tooltipText", flags) ?? t.GetProperty("tooltip", flags);
                if (p != null && p.CanRead && p.PropertyType == typeof(string))
                    return p.GetValue(info, null) as string;

                // Heuristic: first string field containing "tool".
                foreach (var field in t.GetFields(flags))
                {
                    if (field.FieldType != typeof(string))
                        continue;

                    var name = field.Name ?? string.Empty;
                    if (name.IndexOf("tool", StringComparison.OrdinalIgnoreCase) >= 0)
                        return field.GetValue(info) as string;
                }
            }
            catch
            {
                // ignored
            }

            return null;
        }
    }
}
