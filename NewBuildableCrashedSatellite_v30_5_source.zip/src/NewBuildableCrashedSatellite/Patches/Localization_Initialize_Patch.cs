using System;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    /// <summary>
    /// Loads our default strings and applies .po overrides once the game's localization system is initialized.
    /// </summary>
    [HarmonyPatch(typeof(Localization), "Initialize")]
    internal static class Localization_Initialize_Patch
    {
        public static void Postfix()
        {
            try
            {
                LocalizationHelper.Init();
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] Localization.Initialize postfix failed: " + e);
            }
        }
    }
}
