using System;
using System.Collections.Generic;
using HarmonyLib;
using NewBuildableCrashedSatellite.Buildings;
using TUNING;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal static class GeneratedBuildings_LoadGeneratedBuildings_Patch
    {
        private const string ModVersion = "30.4";

        // Prevent duplicate plan-screen insertion when LoadGeneratedBuildings is invoked multiple times.
        // Duplicate entries can crash Codex generation.
        private static readonly HashSet<string> AddedPlanEntries = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Register our custom IBuildingConfig types so the game actually creates BuildingDef's.
        /// Without this, Tech unlocks can show a name (string) but the building will not exist,
        /// resulting in missing icons and not appearing in Plan/Sandbox build lists.
        /// </summary>
        private static void Prefix(List<Type> types)
        {
            try
            {
                if (types == null)
                    return;

                AddConfigTypeOnce(types, typeof(BuildableCrashedSatelliteConfig));
                AddConfigTypeOnce(types, typeof(BuildableWreckedSatelliteConfig));
                AddConfigTypeOnce(types, typeof(BuildableCrushedSatelliteConfig));
            }
            catch (Exception e)
            {
                Debug.LogError("[NBCS v" + ModVersion + "] Failed in GeneratedBuildings.LoadGeneratedBuildings Prefix: " + e);
            }
        }

        private static void Postfix()
        {
            try
            {
                Debug.Log("[NBCS v" + ModVersion + "] GeneratedBuildings.LoadGeneratedBuildings Postfix");

                // Spaced Out!'s radiation build tab internal key is "HEP" (High Energy Physics).
                // Using "Radiation" will not work because that category key does not exist.

                // IMPORTANT: ModUtil.AddBuildingToPlanScreen does NOT de-duplicate.
                // If this postfix runs more than once, the building ID can be inserted multiple
                // times, and Codex generation may crash with:
                //   "Tried to add <ID> to the Codex screen multiple times"
                AddToPlanScreenOnce("HEP", SatelliteIds.BUILDABLE_CRASHED);
                AddToPlanScreenOnce("HEP", SatelliteIds.BUILDABLE_WRECKED);
                AddToPlanScreenOnce("HEP", SatelliteIds.BUILDABLE_CRUSHED);

                // Try to sync Build Menu / Tech icons to the vanilla satellites (avoid the default "clock" placeholder).
                SatellitePatcher.TryApplyBuildableVisualsFromVanilla();
            }
            catch (Exception e)
            {
                Debug.LogError("[NBCS v" + ModVersion + "] Failed in GeneratedBuildings.LoadGeneratedBuildings Postfix: " + e);
            }
        }

        private static void AddConfigTypeOnce(IList<Type> types, Type configType)
        {
            if (types == null || configType == null)
                return;

            if (!types.Contains(configType))
                types.Add(configType);
        }

        private static void AddToPlanScreenOnce(string categoryKey, string buildingId)
        {
            if (string.IsNullOrEmpty(categoryKey) || string.IsNullOrEmpty(buildingId))
                return;

            try
            {
                // De-duplicate ourselves because ModUtil.AddBuildingToPlanScreen does not.
                string key = categoryKey + "|" + buildingId;
                if (!AddedPlanEntries.Add(key))
                    return;

                ModUtil.AddBuildingToPlanScreen(categoryKey, buildingId);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] AddToPlanScreenOnce failed for " + buildingId + " in " + categoryKey + ": " + e);
            }
        }
    }
}
