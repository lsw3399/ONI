using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    /// <summary>
    /// Defensive fix: prevent crashes when a recipe contains more ingredients than the UI currently has selector rows.
    /// 
    /// Some vanilla UI implementations keep a pre-created list/array of MaterialSelector rows.
    /// When mods introduce recipes with a larger ingredient count, the panel may throw ArgumentOutOfRangeException.
    /// This patch grows the selector collection by cloning the existing selector row prefab.
    /// </summary>
    [HarmonyPatch(typeof(MaterialSelectionPanel), nameof(MaterialSelectionPanel.ConfigureScreen),
        new[]
        {
            typeof(Recipe),
            typeof(MaterialSelectionPanel.GetBuildableStateDelegate),
            typeof(MaterialSelectionPanel.GetBuildableTooltipDelegate)
        })]
    internal static class MaterialSelectionPanel_ConfigureScreen_Patch
    {
        public static void Prefix(MaterialSelectionPanel __instance, Recipe recipe)
        {
            try
            {
                MaterialSelectionPanelFix.EnsureSelectorRows(__instance, recipe);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] MaterialSelectionPanel fix failed: " + e);
            }
        }
    }

    internal static class MaterialSelectionPanelFix
    {
        private const BindingFlags FLAGS = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        internal static void EnsureSelectorRows(MaterialSelectionPanel panel, Recipe recipe)
        {
            if (panel == null || recipe == null)
                return;

            int needed = GetIngredientCount(recipe);
            if (needed <= 0)
                return;

            // Ensure every selector collection we can find has enough rows.
            foreach (var field in panel.GetType().GetFields(FLAGS))
                EnsureSelectorCollection(panel, field, needed);
        }

        private static int GetIngredientCount(Recipe recipe)
        {
            var t = recipe.GetType();
            foreach (var name in new[] { "ingredients", "Ingredients" })
            {
                var field = t.GetField(name, FLAGS);
                if (field != null)
                {
                    var val = field.GetValue(recipe);
                    if (val is IList list)
                        return list.Count;
                    if (val is Array arr)
                        return arr.Length;
                }

                var prop = t.GetProperty(name, FLAGS);
                if (prop != null)
                {
                    var val = prop.GetValue(recipe, null);
                    if (val is IList list)
                        return list.Count;
                    if (val is Array arr)
                        return arr.Length;
                }
            }

            return 0;
        }

        private static void EnsureSelectorCollection(MaterialSelectionPanel panel, FieldInfo field, int needed)
        {
            var ft = field.FieldType;

            if (ft.IsGenericType && ft.GetGenericTypeDefinition() == typeof(List<>) && ft.GetGenericArguments()[0] == typeof(MaterialSelector))
            {
                var list = field.GetValue(panel) as IList;
                if (list != null)
                    EnsureList(panel, list, needed);
                return;
            }

            if (ft.IsArray && ft.GetElementType() == typeof(MaterialSelector))
            {
                var arr = field.GetValue(panel) as MaterialSelector[];
                if (arr != null)
                    EnsureArray(panel, field, arr, needed);
            }
        }

        private static void EnsureList(MaterialSelectionPanel panel, IList list, int needed)
        {
            if (list.Count >= needed)
                return;

            var template = FindTemplate(panel, list);
            if (template == null)
                return;

            var parent = template.transform.parent;
            while (list.Count < needed)
            {
                var cloneGo = UnityEngine.Object.Instantiate(template.gameObject, parent);
                // The clone contains TMP link handlers used by the material selector UI.
                // Cloning runtime instances can produce stale TMP link state, which can crash
                // inside TextLinkHandler.OnEnable (IndexOutOfRangeException in TMP_TextUtilities).
                // The links are not required for building construction, so disable them on clones.
                DisableTextLinkHandlers(cloneGo);

                // Match template active state.
                cloneGo.SetActive(template.gameObject.activeSelf);
                var selector = cloneGo.GetComponent<MaterialSelector>();
                if (selector == null)
                {
                    UnityEngine.Object.Destroy(cloneGo);
                    break;
                }
                list.Add(selector);
            }
        }

        private static void EnsureArray(MaterialSelectionPanel panel, FieldInfo field, MaterialSelector[] arr, int needed)
        {
            if (arr.Length >= needed)
                return;

            var template = FindTemplate(panel, arr);
            if (template == null)
                return;

            var parent = template.transform.parent;
            var newList = new List<MaterialSelector>(arr.Length);
            foreach (var s in arr)
                if (s != null)
                    newList.Add(s);

            while (newList.Count < needed)
            {
                var cloneGo = UnityEngine.Object.Instantiate(template.gameObject, parent);
                DisableTextLinkHandlers(cloneGo);
                cloneGo.SetActive(template.gameObject.activeSelf);
                var selector = cloneGo.GetComponent<MaterialSelector>();
                if (selector == null)
                {
                    UnityEngine.Object.Destroy(cloneGo);
                    break;
                }
                newList.Add(selector);
            }

            field.SetValue(panel, newList.ToArray());
        }

        private static MaterialSelector FindTemplate(MaterialSelectionPanel panel, IList list)
        {
            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i] is MaterialSelector sel && sel != null)
                        return sel;
                }
            }
            return FindTemplate(panel);
        }

        private static MaterialSelector FindTemplate(MaterialSelectionPanel panel, MaterialSelector[] arr)
        {
            if (arr != null)
            {
                foreach (var s in arr)
                    if (s != null)
                        return s;
            }
            return FindTemplate(panel);
        }

        private static MaterialSelector FindTemplate(MaterialSelectionPanel panel)
        {
            // Try direct fields first.
            foreach (var f in panel.GetType().GetFields(FLAGS))
            {
                if (f.FieldType == typeof(MaterialSelector))
                {
                    var v = f.GetValue(panel) as MaterialSelector;
                    if (v != null)
                        return v;
                }
            }

            // Fallback: search in children.
            // Prefer an inactive template row if present.
            try
            {
                var all = panel.GetComponentsInChildren<MaterialSelector>(true);
                if (all != null)
                {
                    foreach (var s in all)
                        if (s != null && !s.gameObject.activeSelf)
                            return s;
                    foreach (var s in all)
                        if (s != null)
                            return s;
                }
            }
            catch
            {
            }

            return null;
        }

        private static void DisableTextLinkHandlers(GameObject go)
        {
            if (go == null)
                return;

            try
            {
                var handlers = go.GetComponentsInChildren<TextLinkHandler>(true);
                if (handlers == null)
                    return;

                foreach (var h in handlers)
                    if (h != null)
                        h.enabled = false;
            }
            catch
            {
            }
        }
    }
}
