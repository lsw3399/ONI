using System;
using System.Collections.Generic;
using HarmonyLib;
using NewBuildableCrashedSatellite.Components;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    [HarmonyPatch(typeof(Game), "OnSpawn")]
    internal static class Game_OnSpawn_Patch
    {
        private static void Postfix()
        {
            try
            {
                ReplaceWorldgenSatellitesWithCrashed();
            }
            catch (Exception e)
            {
                Debug.LogError("[NewBuildableCrashedSatellite] Game.OnSpawn replacement failed: " + e);
            }
        }

        private static void ReplaceWorldgenSatellitesWithCrashed()
        {
            GameObject crashedPrefab = null;
            try { crashedPrefab = Assets.GetPrefab(TagManager.Create(SatelliteIds.CRASHED)); } catch { }

            if (crashedPrefab == null)
            {
                Debug.LogWarning("[NewBuildableCrashedSatellite] Crashed Satellite prefab not found; cannot replace worldgen satellites.");
                return;
            }

            Tag wreckedTag = TagManager.Create(SatelliteIds.WRECKED);
            Tag crushedTag = TagManager.Create(SatelliteIds.CRUSHED);

            var toReplace = new List<GameObject>();

            foreach (var kpid in UnityEngine.Object.FindObjectsOfType<KPrefabID>())
            {
                if (kpid == null) continue;
                var tag = kpid.PrefabTag;
                if (tag != wreckedTag && tag != crushedTag)
                    continue;

                if (kpid.GetComponent<PlayerBuiltSatelliteMarker>() != null)
                    continue;

                toReplace.Add(kpid.gameObject);
            }

            foreach (var oldGo in toReplace)
            {
                if (oldGo == null) continue;

                var pos = oldGo.transform.position;
                var rot = oldGo.transform.rotation;

                GameObject newGo = null;
                try
                {
                    newGo = Util.KInstantiate(crashedPrefab, pos, rot);
                }
                catch
                {
                    newGo = UnityEngine.Object.Instantiate(crashedPrefab, pos, rot);
                }

                if (newGo != null)
                    newGo.SetActive(true);

                try { Util.KDestroyGameObject(oldGo); }
                catch { UnityEngine.Object.Destroy(oldGo); }
            }

            if (toReplace.Count > 0)
                Debug.Log("[NewBuildableCrashedSatellite] Replaced worldgen satellites: " + toReplace.Count);
        }
    }
}
