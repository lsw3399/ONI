using System;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    /// <summary>
    /// Runs after all prefabs are created. This is the earliest reliable place to touch
    /// Gravitas/POI prefabs like PropSurfaceSatellite*.
    /// </summary>
    // NOTE: Assets.OnPrefabInit is not public. Using nameof(Assets.OnPrefabInit) triggers CS0122
    // (inaccessible due to protection level) on current ONI builds.
    // Harmony can still patch non-public methods by name, so we use a literal string.
    [HarmonyPatch(typeof(Assets), "OnPrefabInit")]
    internal static class Assets_OnPrefabInit_Patch
    {
        internal static void Postfix()
        {
            try
            {
                // Cache the vanilla satellite visuals (kanim name) so the buildable versions can reuse them.
                SatellitePatcher.CaptureVanillaSatelliteVisuals();

                // Configure vanilla (worldgen) satellite prefabs.
                SatellitePatcher.ConfigureVanillaSatellitePrefabs();

                // Apply cached visuals onto our buildable BuildingDefs (icons, anim files).
                // This must run after vanilla prefabs exist, otherwise Assets.GetAnim(...) may still be null.
                SatellitePatcher.TryApplyBuildableVisualsFromVanilla();
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] Assets.OnPrefabInit Postfix failed: " + e);
            }
        }
    }
}
