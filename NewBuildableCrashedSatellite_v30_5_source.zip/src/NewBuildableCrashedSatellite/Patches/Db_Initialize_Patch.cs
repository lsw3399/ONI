using System;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal static class Db_Initialize_Patch
    {
        private const string ModVersion = "30.4";
        private static bool _applied;

        private static void Postfix()
        {
            if (_applied)
                return;
            _applied = true;

            try
            {
                Debug.Log("[NBCS v" + ModVersion + "] Db.Initialize Postfix (tech unlocks)");

                AddToTech("NuclearStorage", SatelliteIds.BUILDABLE_CRASHED);
                AddToTech("NuclearRefinement", SatelliteIds.BUILDABLE_WRECKED);
                AddToTech("NuclearPropulsion", SatelliteIds.BUILDABLE_CRUSHED);

                // Ensure all recipe material tags are considered buildable materials.
                // This prevents the material picker UI from choking on tags with no build options.
                SatellitePatcher.RegisterBuildMaterials();
            }
            catch (Exception e)
            {
                Debug.LogError("[NBCS v" + ModVersion + "] Db.Initialize Postfix failed: " + e);
            }
        }

        private static void AddToTech(string techId, string buildingId)
        {
            var db = Db.Get();
            if (db == null) return;

            var tech = db.Techs.Get(techId);
            if (tech == null)
            {
                // Some ONI string keys are uppercase; try both to avoid silent failure.
                tech = db.Techs.Get(techId.ToUpperInvariant());
            }

            if (tech == null)
            {
                Debug.LogWarning("[NewBuildableCrashedSatellite] Tech not found: " + techId);
                return;
            }

            var unlocked = tech.unlockedItemIDs;
            if (unlocked == null)
                unlocked = new System.Collections.Generic.List<string>();

            if (!unlocked.Contains(buildingId))
                unlocked.Add(buildingId);

            tech.unlockedItemIDs = unlocked;
        }
    }
}
