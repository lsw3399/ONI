using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    // Patch ALL overloads of Def.GetUISprite(...) to ensure our buildable satellites always get a
    // correctly-sized UI sprite (fixes the oversized icon in the build menu, especially for Crashed Satellite).
    [HarmonyPatch]
    internal static class Def_GetUISprite_Patch
    {
        // ONI uses its own Tuple<T1, T2> type with fields/properties named 'first' and 'second' (not Item1/Item2).
        private static readonly Dictionary<string, Tuple<Sprite, Color>> Cache = new Dictionary<string, Tuple<Sprite, Color>>();

        private static IEnumerable<MethodBase> TargetMethods()
        {
            const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;

            foreach (var m in typeof(Def).GetMethods(flags))
            {
                if (m == null)
                    continue;

                if (!string.Equals(m.Name, "GetUISprite", StringComparison.Ordinal))
                    continue;

                if (m.ReturnType != typeof(Tuple<Sprite, Color>))
                    continue;

                yield return m;
            }
        }

        private static bool Prefix(MethodBase __originalMethod, object[] __args, ref Tuple<Sprite, Color> __result)
        {
            try
            {
                string id = null;
                BuildingDef def = null;

                // Try to find a BuildingDef in args first.
                if (__args != null)
                {
                    for (int i = 0; i < __args.Length; i++)
                    {
                        if (__args[i] is BuildingDef bd)
                        {
                            def = bd;
                            id = bd.PrefabID;
                            break;
                        }
                    }
                }

                // Fallback: look for a string or Tag-like argument.
                if (string.IsNullOrEmpty(id) && __args != null)
                {
                    for (int i = 0; i < __args.Length; i++)
                    {
                        object a = __args[i];
                        if (a == null)
                            continue;

                        if (a is string s)
                        {
                            id = s;
                            break;
                        }

                        // Tag is a struct; ToString() gives the ID name.
                        if (a is Tag tag)
                        {
                            id = tag.ToString();
                            break;
                        }

                        // Some callers may pass objects that stringify to the prefab id.
                        if (id == null && a.GetType().Name == "Tag")
                        {
                            id = a.ToString();
                            break;
                        }
                    }
                }

                if (string.IsNullOrEmpty(id) || !IsBuildableSatellite(id))
                    return true;

                if (Cache.TryGetValue(id, out var cached) && cached != null && cached.first != null)
                {
                    __result = cached;
                    return false;
                }

                if (def == null)
                    def = Assets.GetBuildingDef(id);

                if (def == null || def.BuildingComplete == null)
                    return true;

                // Force the UI anim and centered sprite for consistent icons.
                const string requestedAnim = "ui";
                const bool centered = true;

                var animFiles = TryGetAnimFiles(def);
                var animName = ChooseBestUiAnim(animFiles, requestedAnim, centered);

                Sprite sprite = null;
                if (animFiles != null)
                {
                    for (int i = 0; i < animFiles.Length; i++)
                    {
                        if (animFiles[i] == null)
                            continue;

                        sprite = TryGetSprite(animFiles[i], animName, centered);
                        if (sprite != null)
                            break;
                    }
                }

                if (sprite == null)
                    return true;

                sprite = FixSpriteScaleIfNeeded(id, sprite);

                __result = new Tuple<Sprite, Color>(sprite, Color.white);
                Cache[id] = __result;
                return false;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] Def.GetUISprite patch failed (" + __originalMethod + "): " + e);
                return true;
            }
        }

        private static bool IsBuildableSatellite(string id)
        {
            return id == SatelliteIds.BUILDABLE_CRASHED ||
                   id == SatelliteIds.BUILDABLE_WRECKED ||
                   id == SatelliteIds.BUILDABLE_CRUSHED;
        }

        private static KAnimFile[] TryGetAnimFiles(BuildingDef def)
        {
            try
            {
                var complete = def.BuildingComplete;
                if (complete == null)
                    return null;

                var kbac = complete.GetComponent<KBatchedAnimController>();
                if (kbac != null && kbac.AnimFiles != null && kbac.AnimFiles.Length > 0)
                    return kbac.AnimFiles;

                var kanim = complete.GetComponent<KAnimControllerBase>();
                if (kanim != null && kanim.AnimFiles != null && kanim.AnimFiles.Length > 0)
                    return kanim.AnimFiles;
            }
            catch
            {
            }

            return null;
        }

        private static string ChooseBestUiAnim(KAnimFile[] animFiles, string requested, bool centered)
        {
            // Try requested first.
            if (!string.IsNullOrEmpty(requested) && animFiles != null)
            {
                for (int i = 0; i < animFiles.Length; i++)
                {
                    if (animFiles[i] == null)
                        continue;

                    if (TryGetSprite(animFiles[i], requested, centered) != null)
                        return requested;
                }
            }

            // Common UI symbol candidates.
            var candidates = new[]
            {
                "ui",
                "ui_buildMenu",
                "ui_menu",
                "ui_icon",
                "icon",
                "place",
                "idle"
            };

            if (animFiles != null)
            {
                for (int c = 0; c < candidates.Length; c++)
                {
                    var name = candidates[c];
                    for (int i = 0; i < animFiles.Length; i++)
                    {
                        if (animFiles[i] == null)
                            continue;

                        if (TryGetSprite(animFiles[i], name, centered) != null)
                            return name;
                    }
                }
            }

            return requested ?? "ui";
        }

        private static Sprite TryGetSprite(KAnimFile animFile, string animName, bool centered)
        {
            try
            {
                if (animFile == null)
                    return null;

                var sprite = Def.GetUISpriteFromMultiObjectAnim(animFile, animName, centered);
                return sprite;
            }
            catch
            {
                return null;
            }
        }
        private static Sprite FixSpriteScaleIfNeeded(string id, Sprite original)
        {
            if (original == null)
                return null;

            // Some symbols come back with a bad pixel density (pixelsPerUnit) or a very large rect,
            // which makes the Build Menu icon overflow.
            //
            // In ONI UI, the effective rendered size roughly scales with:
            //   sizePx ~= spriteRectPx * (Canvas.referencePixelsPerUnit / sprite.pixelsPerUnit)
            // Canvas.referencePixelsPerUnit is typically 100.
            const float REF_PPU = 100f;
            const float TARGET_ICON_PX = 64f;

            int w = (int)original.rect.width;
            int h = (int)original.rect.height;

            if (w <= 0 || h <= 0)
                return original;

            float ppu = original.pixelsPerUnit;
            if (ppu <= 0f)
                ppu = REF_PPU;

            float uiW = w * (REF_PPU / ppu);
            float uiH = h * (REF_PPU / ppu);

            // If both the raw rect and the UI-scaled size are already small enough, keep it.
            if (w <= 96 && h <= 96 && uiW <= 96f && uiH <= 96f)
                return original;

            try
            {
                // Preferred fix: normalize sprite pixelsPerUnit so its UI size becomes ~64px.
                // This does NOT require texture readback and is safe for non-readable textures.
                float maxDim = Mathf.Max(w, h);
                float newPPU = maxDim * (REF_PPU / TARGET_ICON_PX);
                if (newPPU <= 0f)
                    newPPU = REF_PPU;

                var tex = original.texture;
                if (tex != null)
                {
                    // Sprite.Create expects a normalized pivot.
                    var pivot = new Vector2(original.pivot.x / w, original.pivot.y / h);
                    var fixedSprite = Sprite.Create(tex, original.rect, pivot, newPPU);
                    if (fixedSprite != null)
                        return fixedSprite;
                }

                // Fallback: resample to 64x64 via GPU readback.
                return ResampleSpriteToSquare(original, 64);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[NBCS] FixSpriteScaleIfNeeded failed for " + id + ": " + e);
                return original;
            }
        }

        private static Sprite ResampleSpriteToSquare(Sprite source, int size)
        {
            if (source == null)
                return null;

            var rt = RenderTexture.GetTemporary(size, size, 0, RenderTextureFormat.ARGB32);
            var prev = RenderTexture.active;

            try
            {
                RenderTexture.active = rt;
                GL.Clear(true, true, new Color(0, 0, 0, 0));

                var rect = source.rect;
                var tex = source.texture;
                if (tex == null)
                    return source;

                // Convert sprite rect to UV.
                var uv = new Rect(rect.x / tex.width, rect.y / tex.height, rect.width / tex.width, rect.height / tex.height);

                Graphics.DrawTexture(new Rect(0, 0, size, size), tex, uv, 0, 0, 0, 0);

                var tex2d = new Texture2D(size, size, TextureFormat.ARGB32, false);
                tex2d.ReadPixels(new Rect(0, 0, size, size), 0, 0);
                tex2d.Apply(false, false);

                return Sprite.Create(tex2d, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
            }
            finally
            {
                RenderTexture.active = prev;
                RenderTexture.ReleaseTemporary(rt);
            }
        }

    }
}
