using System;
using HarmonyLib;

namespace NewBuildableCrashedSatellite.Patches
{
    /// <summary>
    /// Guards against rare TextMeshPro linked-overflow related exceptions (IndexOutOfRange/ArgumentOutOfRange)
    /// triggered by TextLinkHandler.CheckMouseOver().
    ///
    /// This is a UI-only safety net to prevent hard crashes when opening long tooltips / material panels.
    /// </summary>
    [HarmonyPatch]
    internal static class TextLinkHandler_CheckMouseOver_Patch
    {
        private static System.Reflection.MethodBase TargetMethod()
        {
            return AccessTools.Method("TextLinkHandler:CheckMouseOver");
        }

        private static Exception Finalizer(Exception __exception)
        {
            if (__exception is IndexOutOfRangeException || __exception is ArgumentOutOfRangeException)
                return null;
            return __exception;
        }
    }
}
