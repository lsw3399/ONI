using System;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite.Patches
{
    /// <summary>
    /// Safety net: some UI elements (notably MaterialSelectionPanel selector rows) can crash inside
    /// TextLinkHandler.OnEnable when cloned at runtime (IndexOutOfRangeException inside TMP_TextUtilities).
    ///
    /// The link-hover feature is not required to build our satellites, so we suppress these exceptions
    /// to prevent a hard crash when selecting the building in the Plan Screen.
    /// </summary>
    [HarmonyPatch(typeof(TextLinkHandler), "OnEnable")]
    internal static class TextLinkHandler_OnEnable_Patch
    {
        private static bool _logged;

        public static Exception Finalizer(Exception __exception)
        {
            if (__exception == null)
                return null;

            if (__exception is IndexOutOfRangeException || __exception is ArgumentOutOfRangeException)
            {
                if (!_logged)
                {
                    _logged = true;
                    Debug.LogWarning("[NBCS] Suppressed TextLinkHandler.OnEnable exception (TMP link state). This prevents a crash when selecting a buildable satellite.");
                }
                return null; // swallow
            }

            return __exception;
        }
    }
}
