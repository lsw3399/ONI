using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace NewBuildableCrashedSatellite
{
    public sealed class Mod : KMod.UserMod2
    {
        private const string ModVersion = "30.5";

        public override void OnLoad(Harmony harmony)
        {
            base.OnLoad(harmony);

            try
            {
                // Cache the resolved mod folder path for translation loading, etc.
                ModAssets.Init(mod);

                // Klei 가이드: UserMod2.OnLoad 를 override 하면 PatchAll()을 직접 호출해야 패치가 적용됩니다.
                // (그렇지 않으면 [HarmonyPatch] 클래스가 전부 무시됩니다.)
                harmony.PatchAll();

                // Localization.Initialize 가 이미 실행된 경우를 대비해 여기서도 번역을 한 번 적용합니다.
                // (Localization_Initialize_Patch 에서도 재시도하므로 중복 호출은 안전합니다.)
                LocalizationHelper.Init();

                bool dlc1Active = false;
                try
                {
                    dlc1Active = DlcManager.IsExpansion1Active();
                }
                catch { }

                Assembly asm = typeof(Mod).Assembly;
                Debug.Log("[NBCS v" + ModVersion + "] OnLoad OK | DLC1Active=" + dlc1Active +
                          " | HarmonyId=" + harmony.Id +
                          " | Assembly=" + asm.FullName +
                          " | Location=" + SafeLocation(asm));
            }
            catch (Exception e)
            {
                Debug.LogError("[NBCS v" + ModVersion + "] OnLoad FAILED: " + e);
                throw;
            }
        }

        private static string SafeLocation(Assembly asm)
        {
            try { return asm.Location ?? ""; }
            catch { return ""; }
        }
    }
}
