using System;
using UnityEngine;

namespace NewBuildableCrashedSatellite
{
    internal static class SatelliteTuning
    {
        internal struct BuildRecipe
        {
            public string[] materialTags;
            public float[] massesKg;

            public BuildRecipe(string[] materialTags, float[] massesKg)
            {
                this.materialTags = materialTags;
                this.massesKg = massesKg;
            }

            // Convenience aliases (older versions of this project used these names).
            // Keeping them avoids needless churn in building config code.
            public string[] Materials => materialTags;
            public float[] Masses => massesKg;
        }

        internal static BuildRecipe GetRecipe(string prefabId)
        {
            switch (prefabId)
            {
                case SatelliteIds.CRASHED:
                case SatelliteIds.BUILDABLE_CRASHED:
                    return new BuildRecipe(
                        new string[]
                        {
                            SimHashes.UraniumOre.ToString(),
                            SimHashes.Tungsten.ToString(),
                            SimHashes.Copper.ToString(),
                            SimHashes.Iron.ToString(),
                            SimHashes.Gold.ToString(),
                            SimHashes.Glass.ToString(),
                        },
                        new float[] { 800f, 2000f, 1000f, 1000f, 1000f, 800f }
                    );

                case SatelliteIds.WRECKED:
                case SatelliteIds.BUILDABLE_WRECKED:
                    return new BuildRecipe(
                        new string[]
                        {
                            SimHashes.UraniumOre.ToString(),
                            SimHashes.Steel.ToString(),
                            SimHashes.Gold.ToString(),
                            SimHashes.Polypropylene.ToString(),
                            SimHashes.Diamond.ToString(),
                            SimHashes.Glass.ToString(),
                        },
                        new float[] { 2000f, 3000f, 2000f, 2000f, 4000f, 2000f }
                    );

                case SatelliteIds.CRUSHED:
                case SatelliteIds.BUILDABLE_CRUSHED:
                    return new BuildRecipe(
                        new string[]
                        {
                            SimHashes.EnrichedUranium.ToString(),
						// Thermium element id is TempConductorSolid.
						"TempConductorSolid",
                            SimHashes.Gold.ToString(),
						// Plastium element id is HardPolypropylene.
						"HardPolypropylene",
                            SimHashes.Diamond.ToString(),
                            SimHashes.Glass.ToString(),
                        },
                        new float[] { 10000f, 5000f, 20000f, 2000f, 20000f, 20000f }
                    );

                default:
                    throw new ArgumentException("Unknown satellite prefab id: " + prefabId);
            }
        }

        internal const float CRASHED_RADS_PER_CYCLE = 2000f;
        internal const float WRECKED_RADS_PER_CYCLE = 8000f;

        // Crushed: per-tile rads is dynamic.
        internal const float CRUSHED_BASE_TILE_RADS_PER_CYCLE = 60000f;
        internal const int CRUSHED_BASE_WIDTH = 6;
        internal const int CRUSHED_BASE_HEIGHT = 6;
        internal const int CRUSHED_MAX_EXTEND = 6;

        internal static float CrushedTotalRadsPerCycleBase()
        {
            // Total is defined as (base 6x6 tiles) * (60000 rads per tile)
            return CRUSHED_BASE_WIDTH * CRUSHED_BASE_HEIGHT * CRUSHED_BASE_TILE_RADS_PER_CYCLE;
        }

        internal static float CrushedTotalRadsPerCyclePowered()
        {
            // Total is defined as (base 6x6 tiles) * (100000 rads per tile)
            const float poweredTileRadsPerCycle = 120000f;
            return CRUSHED_BASE_WIDTH * CRUSHED_BASE_HEIGHT * poweredTileRadsPerCycle;
        }

        internal static float CToK(float c) => c + 273.15f;

        // Heat output is given in kDTU/s in the requirement.
        internal const float CRASHED_HEAT_KDTU_PER_S = 20f;
        internal const float WRECKED_HEAT_BASE_KDTU_PER_S = 60f;
        internal const float WRECKED_HEAT_POWERED_KDTU_PER_S = 180f;
        internal const float CRUSHED_HEAT_BASE_KDTU_PER_S = 400f;
        internal const float CRUSHED_HEAT_POWERED_KDTU_PER_S = 1600f;

        internal const float CRASHED_STOP_C = 125f;
        internal const float WRECKED_STOP_C = 400f;
        internal const float CRUSHED_STOP_C = 2000f;

        
        // UI-only: set BuildingDef.OverheatTemperature high enough to avoid early breakdown; runtime stop logic is enforced separately.
        // (Actual runtime stop logic is enforced by controllers.)
        internal static readonly float CRASHED_OVERHEAT_TEMP_K = CToK(CRASHED_STOP_C);
        internal static readonly float WRECKED_OVERHEAT_TEMP_K = CToK(WRECKED_STOP_C);
        internal static readonly float CRUSHED_OVERHEAT_TEMP_K = CToK(CRUSHED_STOP_C);

	internal const float WRECKED_POWER_WATTS = 400f;
        internal const float CRUSHED_POWER_WATTS = 4000f;

        // Crushed ports: Ports are aligned around the building center (no additional shift).
        // Building footprint is 6 wide (centerX = 2), aligned around center:
        // - Power: (-1,0)
        // - Logic: ( 1,0)
        // - Liquid output: (-2,0)
        // - Gas output: ( 2,0)
        internal static readonly CellOffset CRUSHED_POWER_OFFSET = new CellOffset(-1, 0);
        internal static readonly CellOffset CRUSHED_LOGIC_OFFSET = new CellOffset(1, 0);
        internal static readonly CellOffset CRUSHED_LIQUID_OUTPUT_OFFSET = new CellOffset(-2, 0);
        internal static readonly CellOffset CRUSHED_GAS_OUTPUT_OFFSET = new CellOffset(2, 0);

        internal const float WRECKED_POWERED_LUX = 50000f;
        internal const float CRUSHED_POWERED_LUX = 100000f;

        // Per-tile radiation increases from 60,000 -> 120,000 rads/cycle when powered (2x).
        internal const float CRUSHED_POWERED_RADS_MULTIPLIER = 2f;

        internal const float CRUSHED_LIQUID_KG_PER_S = 4f;
        internal const float CRUSHED_LIQUID_TEMP_C = 85f;
        internal const float CRUSHED_GAS_KG_PER_S = 0.42f; // 420 g/s
        internal const float CRUSHED_GAS_TEMP_C = 425f;
    }
}
