namespace NewBuildableCrashedSatellite
{
    internal static class SatelliteIds
    {
        // Vanilla (worldgen) prefab IDs (Spaced Out!)
        public const string CRASHED = "PropSurfaceSatellite1";
        public const string WRECKED = "PropSurfaceSatellite2";
        public const string CRUSHED = "PropSurfaceSatellite3";

        // Buildable (mod) building IDs
        public const string BUILDABLE_CRASHED = "NBCS_CrashedSatellite";
        public const string BUILDABLE_WRECKED = "NBCS_WreckedSatellite";
        public const string BUILDABLE_CRUSHED = "NBCS_CrushedSatellite";
    }
}
